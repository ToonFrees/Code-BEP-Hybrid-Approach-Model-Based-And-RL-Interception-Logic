def done_function(state):
    state = state.T
    i = 18
    dist_robot_target = ((state[22-i] - state[18-i]) ** 2 + (state[23-i] - state[19-i]) ** 2) ** 0.5
    if dist_robot_target < 0.2 or abs(state[18-i]) > 4 or abs(state[19-i]) > 6:
        terminated = True
    else:
        terminated = False

    return terminated