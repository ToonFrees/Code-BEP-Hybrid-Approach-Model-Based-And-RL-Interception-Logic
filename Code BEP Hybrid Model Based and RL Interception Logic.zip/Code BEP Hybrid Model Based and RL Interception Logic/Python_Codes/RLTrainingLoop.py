import torch
import os
import numpy as np
import torch.nn as nn
from stable_baselines3 import SAC
from stable_baselines3.common.vec_env import DummyVecEnv
import matplotlib.pyplot as plt
# from Python_Codes.MBPO2 import MBPO
from Python_Codes.RobotEnvironment import Robot  # assuming you have this
from stable_baselines3.common.env_checker import check_env
from gymnasium import ActionWrapper
from gymnasium.spaces import Box

def normalize(x, mean, std):
    return (x - mean) / std

def denormalize(x, mean, std):
    return x * std + mean

class NormalizeActionWrapper(ActionWrapper):
    def __init__(self, env):
        super().__init__(env)
        assert isinstance(env.action_space, Box)
        self._orig_low = env.action_space.low
        self._orig_high = env.action_space.high
        self.action_space = Box(low=-1.0, high=1.0, shape=self._orig_low.shape, dtype=np.float32)

    def action(self, action):
        return self._orig_low + (action + 1.0) * 0.5 * (self._orig_high - self._orig_low)

    def reverse_action(self, action):
        return 2.0 * (action - self._orig_low) / (self._orig_high - self._orig_low) - 1.0

save_path = "sac_checkpoints_14_06"
resume_training = True  # Set to True if you want to resume training
resume_path = os.path.join("sac_checkpoints_13_06", "sac_latest.zip")  # latest checkpoint
# "sac_agent_relative_good_trajectory_no_overfit.zip" good basis
# Environment and model setup
env = Robot()  # wrap your MATLAB sim
check_env(env)
print('past environment')





env = NormalizeActionWrapper(env)
vec_env = DummyVecEnv([lambda: env])

# agent = SAC("MlpPolicy", vec_env, verbose=1)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device} ({torch.cuda.get_device_name(0) if device.type == 'cuda' else 'CPU'})")

# policy_kwargs = dict(net_arch=[128, 128, 128], activation_fn=torch.nn.ReLU)
# agent = SAC("MlpPolicy", vec_env, verbose=1)
if resume_training and os.path.exists(resume_path):
    print("Loading model from checkpoint...")
    agent = SAC.load(resume_path, env=vec_env, device=device)  # reload agent
else:
    agent = SAC("MlpPolicy", vec_env, verbose=1, device = device)



# Store evaluation rewards over time
eval_rewards = []
eval_epochs = []

def evaluate(agent, env, episodes=5, epoch=0):
    total_rewards = []
    for _ in range(episodes):
        state, _ = env.reset()
        done = False
        total_reward = 0
        while not done:
            action, _ = agent.predict(state, deterministic=True)
            state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            total_reward += reward
        total_rewards.append(total_reward)

    avg_reward = np.mean(total_rewards)
    eval_rewards.append(avg_reward)
    eval_epochs.append(epoch)

    print(f"[Eval @ Epoch {epoch}] Avg Reward: {avg_reward:.2f}")

    # Plotting
    plt.figure(figsize=(8, 5))
    plt.plot(eval_epochs, eval_rewards, label="Avg Eval Reward")
    plt.xlabel("Epoch")
    plt.ylabel("Average Evaluation Reward")
    plt.title("SAC Evaluation Reward Over Time")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("eval_progress.png")   # Optional: saves the figure
    plt.pause(0.01)                    # Allow the plot to update live
    plt.clf()                          # Clear figure for next update



os.makedirs(save_path, exist_ok=True)
step = 0
# Now run model-based training
# Set up checkpointin

# Train in chunks
total_timesteps = 1_500_000
timesteps_per_epoch = 5000
epochs = total_timesteps // timesteps_per_epoch

plt.ion()

for epoch in range(epochs):
    print(f"=== Epoch {epoch} ===")
    agent.learn(total_timesteps=timesteps_per_epoch, reset_num_timesteps=False)

    # Save latest model for resuming
    latest_path = os.path.join(save_path, "sac_latest.zip")
    agent.save(latest_path)

    # Optionally save a timestamped checkpoint

    if epoch % 5 == 0:
        agent.save(os.path.join(save_path, f"sac_epoch_{epoch}.zip"))
        print('start_evaluation')
        evaluate(agent, env, epoch=epoch)


# Final save
agent.save("sac_model_free_final.zip")
torch.save(agent.actor.state_dict(), "sac_actor_only.pth")

