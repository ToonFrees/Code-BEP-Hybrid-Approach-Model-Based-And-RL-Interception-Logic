import numpy as np
import math

from Python_Codes.FunctionPointOnCircle import random_point_in_circle

def generate_episode_data(easy_ratio=1):
    angle_disturbance_range_old = 16*np.pi/16
    angle_disturbance_range_new = 16*np.pi/16
    magnitude_velocity_ball_old = 2
    magnitude_velocity_ball_new = 2
    v_initial_old = [0,0,0]
    v_initial_new_magnitude = 1
    if np.random.rand() < easy_ratio:
        # Sample from easier distribution
        ball_pos_center = [0,0]
        ball_pos_radius = 2
        robot_pos_radius = 2.5
        magnitude = np.random.uniform(0, magnitude_velocity_ball_old)
        angle_disturbance = np.random.uniform(-angle_disturbance_range_old, angle_disturbance_range_old)
    else:
        # Sample from harder distribution
        ball_pos_center = [0, 0]  # increase the magnitude range
        magnitude = np.random.uniform(magnitude_velocity_ball_old, magnitude_velocity_ball_new)
        robot_pos_radius = 3
        ball_pos_radius = 2
        if np.random.rand() < 0.5:
            angle_disturbance = np.random.uniform(-angle_disturbance_range_new, -angle_disturbance_range_old)
        else:
            angle_disturbance = np.random.uniform(angle_disturbance_range_old, angle_disturbance_range_new)

    # Sample initial ball position
    p_initial_ball = random_point_in_circle(ball_pos_center, ball_pos_radius)[:2]

    # Initial direction vector
    v_initial_ball = np.array([-0.1, 0.7])

    # Sample magnitude and disturbed angle
    original_angle = np.arctan2(v_initial_ball[1], v_initial_ball[0])

    new_angle = original_angle + angle_disturbance

    # New disturbed velocity vector
    v_initial_ball = magnitude * np.array([np.cos(new_angle), np.sin(new_angle)])

    # Initial robot position and velocity
    p_initial = random_point_in_circle(p_initial_ball, robot_pos_radius)
    # v_initial = [0,0,0]
    if np.random.rand() <= easy_ratio:
        # Vector from robot to ball
        direction_vector = np.array(p_initial_ball) - np.array(p_initial[:2])
        base_angle = np.arctan2(direction_vector[1], direction_vector[0])

        # Apply disturbance within ±π/4
        angle_offset = np.random.uniform(-np.pi/2, np.pi/2)
        new_robot_angle = base_angle + angle_offset

        # Sample magnitude between 0 and 0.5
        robot_speed = np.random.uniform(0, v_initial_new_magnitude)
        vx = robot_speed * np.cos(new_robot_angle)
        vy = robot_speed * np.sin(new_robot_angle)

        v_initial = [vx, vy, 0]
    else:
        v_initial = [0, 0, 0]

    v_initial = [0,0,0]

    return p_initial_ball, v_initial_ball, p_initial, v_initial