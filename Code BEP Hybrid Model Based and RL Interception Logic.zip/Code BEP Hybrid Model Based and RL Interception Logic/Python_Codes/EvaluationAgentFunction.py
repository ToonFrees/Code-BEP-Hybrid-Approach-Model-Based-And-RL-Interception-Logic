import numpy as np

def evaluation_agent(state):
    robot_pos = state[22:24]
    robot_vel = state[25:27]
    ball_pos = state[18:20]
    ball_vel = state[20:22]

    distance = np.linalg.norm(robot_pos - ball_pos)

    if distance < 0.2:
        dot_prod = np.dot(-robot_vel, ball_vel)
        denominator = np.linalg.norm(robot_vel) * np.linalg.norm(ball_vel)
        cos_theta = dot_prod / denominator
        angle = np.arccos(cos_theta)

        robot_vel_magn = np.linalg.norm(robot_vel)
        relative_velocity = np.linalg.norm(robot_vel-ball_vel)

    else:
        angle = None
        robot_vel_magn = None
        relative_velocity = None

    return angle, robot_vel_magn, relative_velocity