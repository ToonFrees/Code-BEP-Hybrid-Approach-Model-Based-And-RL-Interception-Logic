import gym
import gymnasium as gym
from gymnasium import Env
from gymnasium.spaces import Box

import csv
import time

import torch

import numpy as np
import random
import os

import torch.nn as nn



from stable_baselines3 import SAC
from gymnasium import ActionWrapper
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.evaluation import evaluate_policy

path = os.path.join("C:", "Users", "20223628", "OneDrive - TU Eindhoven", "Documents", "BEP 2025")

from velocity_generator import generate_velocity
from Link_Matlab_Python_Codes.RewardFunctionsUsed.BacToBasic import reward_function
from Link_Matlab_Python_Codes.DoneFunctionNewObservationSpce import done_function
from Link_Matlab_Python_Codes.EvaluationAgentFunction import evaluation_agent
from Link_Matlab_Python_Codes.AngleBetween import angle_between

import pickle

with open('test_cases_new.pickle', 'rb') as f:
    test_cases = pickle.load(f)


import matlab.engine

m = matlab.engine.connect_matlab('MATLAB_37272')
m.eval('clear all; close all; clc', nargout=0)

use_test_case = True

def format_float(f):
    return str(f).replace('.', ',')

def matlab_to_numpy(var):
    """Convert MATLAB type to flattened NumPy float32 array."""
    return np.array(m.workspace[var], dtype=np.float32).flatten()

norm_stats = torch.load('normalization_stats.pth', weights_only=True)
state_mean = norm_stats['state_mean'].float()
state_std = norm_stats['state_std'].float()
action_mean = norm_stats['action_mean'].float()
action_std = norm_stats['action_std'].float()

class NormalizeActionWrapper(ActionWrapper):
    def __init__(self, env):
        super().__init__(env)
        assert isinstance(env.action_space, Box)
        self._orig_low = env.action_space.low
        self._orig_high = env.action_space.high
        self.action_space = Box(low=-1.0, high=1.0, shape=self._orig_low.shape, dtype=np.float32)

    def action(self, action):
        return self._orig_low + (action + 1.0) * 0.5 * (self._orig_high - self._orig_low)

    def reverse_action(self, action):
        return 2.0 * (action - self._orig_low) / (self._orig_high - self._orig_low) - 1.0


def normalize(x, mean, std):
    return (x - mean.numpy()) / std.numpy()

def denormalize(x, mean, std):
    return x * std.numpy() + mean.numpy()

results_path = os.path.join("EvaluationResultsAgent", "evaluation_results_agent_test_angle.csv")

if os.path.exists(results_path):
    with open(results_path, 'r') as f:
        existing_lines = sum(1 for _ in f)
else:
    existing_lines = 0

print(f"Resuming from episode {existing_lines + 1}")


action_dim = 2
class Robot(Env):
    info = np.zeros(action_dim)
    reset_calls = 0
    def __init__(self):
        self.action_space = Box(low=-4, high=4, shape=(2,), dtype=np.float32)
        #self.state = SimpleNamespace(
        #   obstacles=SimpleNamespace(p=None, v=None),
        #   robot=SimpleNamespace(p=None, v=None, traj=None),
        #    target=SimpleNamespace(p=None, eta=None)
        #)
        self.timestep = 0
        self.timesteps_distance_low = 0
        p_initial = [
            random.uniform(-4, 4),
            random.uniform(-6, 6),
            0
        ]
        v_initial = [0, 0, 0]#generate_velocity(4)
        p_input_target =  [
            random.uniform(-4, 4),
            random.uniform(-6, 6),
            0
        ]
        npredict = 20
        nobstacles = min(9, 78)
        nintercept_positions = 15
        p_initial_ball =  [
            random.uniform(-4, 4),
            random.uniform(-6, 6)
        ]
        v_initial_ball = generate_velocity(2)[:2]



        p_initial_matlab = matlab.double([p_initial])
        m.workspace['p_initial'] = p_initial_matlab
        v_initial_matlab = matlab.double([v_initial])
        m.workspace['v_initial'] = v_initial_matlab
        p_input_target_matlab = matlab.double([p_input_target])
        m.workspace['p_input_target'] = p_input_target_matlab
        npredict_matlab = matlab.double([npredict])
        m.workspace['npredict'] = npredict_matlab
        nobstacles_matlab = matlab.double([nobstacles])
        m.workspace['nobstacles'] = nobstacles_matlab
        nintercept_positions_matlab = matlab.double([nintercept_positions])
        m.workspace['nintercept_positions'] = nintercept_positions_matlab
        p_initial_ball_matlab = matlab.double([p_initial_ball])
        m.workspace['p_initial_ball'] = p_initial_ball_matlab
        v_initial_ball_matlab = matlab.double([v_initial_ball])
        m.workspace['v_initial_ball'] = v_initial_ball_matlab

        m.main(nargout=0)


        #m.extract_values(nargout=0)
        vars = [
            'p_input_ball', 'v_input_ball',
            'p_input_robot', 'v_input_robot', 'a_robot',
            'p_target', 'v_target', 'target_velocity',
            'traj_robot_p', 'traj_robot_v', 'traj_robot_a',
            'eta', 'distance', 'angle_robotball_vel',
            'angle_robot_ball_end', 'angle_traj_vel_ball_vel'
        ]
        features = []

        for var in vars:
            arr = matlab_to_numpy(var)
            features.append(arr)  # flatten to 1D if needed

        self.prev_action = np.zeros(self.action_space.shape[0])
        action = [0,0]
        angle_prev_action_action = angle_between(action, self.prev_action)
        ball_velocity = matlab_to_numpy('v_target')
        angle_target_vel_ball_vel = angle_between(action, -ball_velocity)

        features.append(np.array([angle_prev_action_action], dtype=np.float32))
        features.append(np.array([angle_target_vel_ball_vel], dtype=np.float32))
        features.append(np.array(self.prev_action, dtype=np.float32)) # if prev_action is a NumPy array
        features.append(np.array([self.timestep], dtype=np.float32))
        distance_traj_vel = matlab_to_numpy('distance_traj_vel')
        features.append(distance_traj_vel)

        robot_pos = matlab_to_numpy('p_input_robot')[:2]  # x, y
        ball_pos = matlab_to_numpy('p_input_ball')[:2]

        distance_to_left_robot = robot_pos[0] - (-4)
        distance_to_right_robot = 4 - robot_pos[0]
        distance_to_bottom_robot = robot_pos[1] - (-6)
        distance_to_top_robot = 6 - robot_pos[1]

        distance_to_left_ball = ball_pos[0] - (-4)
        distance_to_right_ball = 4 - ball_pos[0]
        distance_to_bottom_ball = ball_pos[1] - (-6)
        distance_to_top_ball = 6 - ball_pos[1]

        distances_to_boundaries = np.array([
            distance_to_left_robot,
            distance_to_right_robot,
            distance_to_bottom_robot,
            distance_to_top_robot,
            distance_to_left_ball,
            distance_to_right_ball,
            distance_to_bottom_ball,
            distance_to_top_ball,
        ], dtype=np.float32)

        features.append(distances_to_boundaries)

        self.state = np.concatenate(features)


        low = -15 * np.ones(len(self.state), dtype=np.float32)
        high = 15 * np.ones(len(self.state), dtype=np.float32)

        # Set manual bounds for index 138 and 166
        low[187-49] = 0  # e.g. -1
        high[187-49] = 50  # e.g. 1

        low[215-49] = 0  # e.g. 0
        high[215-49] = 5000  # e.g. 5

        # Define observation space
        self.observation_space = Box(low=low, high=high, shape=(len(self.state),), dtype=np.float32)

        self.test_cases = None
        self.test_index = 0
        self.use_test_cases = True  # flag to control whether to use them




    def set_test_cases(self, test_cases, test_index):
        """Set the fixed test cases for evaluation or scripted experiments."""
        self.test_cases = test_cases
        self.test_index = test_index
        self.use_test_cases = True



    def step(self, action):
        norm = np.linalg.norm(action)
        if norm > 4:
            action = action / norm * 4
        action_3d = np.append(action, 0.0)  # shape: [x, y, z=0]
        action_matlab = matlab.double(np.array(action_3d, dtype=np.float64).flatten().tolist())
        m.workspace['action_target_velocity'] = action_matlab
        m.step_separate_file(nargout=0)
        m.update_separate_file(nargout=0)
        vars = [
            'p_ball', 'v_ball',
            'p_robot', 'v_robot', 'a_robot',
            'p_target', 'v_target', 'target_velocity',
            'traj_robot_p', 'traj_robot_v', 'traj_robot_a',
            'eta', 'distance', 'angle_robotball_vel',
            'angle_robot_ball_end', 'angle_traj_vel_ball_vel'
        ]
        features = []

        for var in vars:
            arr = matlab_to_numpy(var)
            features.append(arr)  # flatten to 1D if needed

        angle_prev_action_action = angle_between(action, self.prev_action)
        ball_velocity = matlab_to_numpy('v_target')
        angle_target_vel_ball_vel = angle_between(action, -ball_velocity)

        features.append(np.array([angle_prev_action_action], dtype=np.float32))
        features.append(np.array([angle_target_vel_ball_vel], dtype=np.float32))
        features.append(np.array(self.prev_action, dtype=np.float32))  # if prev_action is a NumPy array
        features.append(np.array([self.timestep], dtype=np.float32))
        distance_traj_vel = matlab_to_numpy('distance_traj_vel')
        features.append(distance_traj_vel)

        robot_pos = matlab_to_numpy('p_robot')[:2]  # x, y
        ball_pos = matlab_to_numpy('p_target')[:2]

        distance_to_left_robot = robot_pos[0] - (-4)
        distance_to_right_robot = 4 - robot_pos[0]
        distance_to_bottom_robot = robot_pos[1] - (-6)
        distance_to_top_robot = 6 - robot_pos[1]

        distance_to_left_ball = ball_pos[0] - (-4)
        distance_to_right_ball = 4 - ball_pos[0]
        distance_to_bottom_ball = ball_pos[1] - (-6)
        distance_to_top_ball = 6 - ball_pos[1]

        distances_to_boundaries = np.array([
            distance_to_left_robot,
            distance_to_right_robot,
            distance_to_bottom_robot,
            distance_to_top_robot,
            distance_to_left_ball,
            distance_to_right_ball,
            distance_to_bottom_ball,
            distance_to_top_ball,
        ], dtype=np.float32)

        features.append(distances_to_boundaries)

        if np.linalg.norm(robot_pos - ball_pos) < 0.25:
            self.timesteps_distance_low += 1
        else:
            self.timesteps_distance_low = 0



        next_state = np.concatenate(features)
        reward = reward_function(next_state, action, self.timesteps_distance_low)
        self.state = next_state
        # norm_state = normalize(self.state, state_mean, state_std)
        # print(len(self.state))
        terminated = done_function(next_state)
        if self.timestep > 3000:
            truncated = True
        else:
            truncated = False
        done = terminated or truncated


        # Robot



        self.prev_action = action  # update prev action
        info = {}  # for logging/debugging if needed
        self.timestep += 1
        reward = float(reward)

        return self.state, reward, done, info
    def render(self):
        pass
    def reset(self, seed=None, options=None):
        Robot.reset_calls += 1
        print(f"Robot reset called {Robot.reset_calls} times")
        super().reset(seed=seed) if hasattr(super(), "reset") else None


        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
        self.timestep = 0
        self.timesteps_distance_low = 0

        # p_initial_ball = random_point_in_circle([0, 0], 1)[:2]
        # p_initial = random_point_in_circle(p_initial_ball, 2)
        # v_initial = [0, 0, 0]
        # v_initial_ball = generate_velocity(0.5)[:2]
        # p_initial_ball = random_point_in_circle([0,0], 2)[:2]
        # v_initial_ball = np.array([-0.1, 0.7])
        #
        # # Compute magnitude and angle of the original vector
        # magnitude = 1
        # magnitude = np.random.uniform(0, magnitude)
        # original_angle = np.arctan2(v_initial_ball[1], v_initial_ball[0])  # in radians
        #
        # # Add random disturbance in angle within ±π/8
        # angle_disturbance = np.random.uniform(-3*np.pi/8, 3*np.pi/8)
        # new_angle = original_angle + angle_disturbance
        #
        # # Compute new vector with same magnitude and disturbed angle
        # v_initial_ball = magnitude * np.array([np.cos(new_angle), np.sin(new_angle)])
        # p_initial = random_point_in_circle(p_initial_ball, 2)
        # v_initial = [0,0,0]
        if use_test_case and hasattr(self, 'test_cases'):
            test_case = self.test_cases[self.test_index % len(self.test_cases)]
            self.test_index += 1

            p_initial = test_case["p_initial"]
            v_initial = test_case["v_initial"]
            p_initial_ball = test_case["p_initial_ball"]
            v_initial_ball = test_case["v_initial_ball"]

        p_initial_matlab = matlab.double([p_initial])
        m.workspace['p_initial'] = p_initial_matlab
        v_initial_matlab = matlab.double([v_initial])
        m.workspace['v_initial'] = v_initial_matlab
        p_initial_ball_matlab = matlab.double([p_initial_ball])
        m.workspace['p_initial_ball'] = p_initial_ball_matlab
        v_initial_ball_matlab = matlab.double([v_initial_ball])
        m.workspace['v_initial_ball'] = v_initial_ball_matlab

        m.main(nargout=0)
        vars = [
            'p_input_ball', 'v_input_ball',
            'p_input_robot', 'v_input_robot', 'a_robot',
            'p_target', 'v_target', 'target_velocity',
            'traj_robot_p', 'traj_robot_v', 'traj_robot_a',
            'eta', 'distance', 'angle_robotball_vel',
            'angle_robot_ball_end', 'angle_traj_vel_ball_vel'
        ]
        features = []

        for var in vars:
            arr = matlab_to_numpy(var)
            features.append(arr)  # flatten to 1D if needed

        self.prev_action = np.zeros(self.action_space.shape[0])
        action = [0, 0]
        angle_prev_action_action = angle_between(action, self.prev_action)
        ball_velocity = matlab_to_numpy('v_target')
        angle_target_vel_ball_vel = angle_between(action, -ball_velocity)

        features.append(np.array([angle_prev_action_action], dtype=np.float32))
        features.append(np.array([angle_target_vel_ball_vel], dtype=np.float32))
        features.append(np.array(self.prev_action, dtype=np.float32))  # if prev_action is a NumPy array
        features.append(np.array([self.timestep], dtype=np.float32))
        distance_traj_vel = matlab_to_numpy('distance_traj_vel')
        features.append(distance_traj_vel)

        robot_pos = matlab_to_numpy('p_input_robot')[:2]  # x, y
        ball_pos = matlab_to_numpy('p_input_ball')[:2]

        distance_to_left_robot = robot_pos[0] - (-4)
        distance_to_right_robot = 4 - robot_pos[0]
        distance_to_bottom_robot = robot_pos[1] - (-6)
        distance_to_top_robot = 6 - robot_pos[1]

        distance_to_left_ball = ball_pos[0] - (-4)
        distance_to_right_ball = 4 - ball_pos[0]
        distance_to_bottom_ball = ball_pos[1] - (-6)
        distance_to_top_ball = 6 - ball_pos[1]

        distances_to_boundaries = np.array([
            distance_to_left_robot,
            distance_to_right_robot,
            distance_to_bottom_robot,
            distance_to_top_robot,
            distance_to_left_ball,
            distance_to_right_ball,
            distance_to_bottom_ball,
            distance_to_top_ball,
        ], dtype=np.float32)

        features.append(distances_to_boundaries)




        self.state = np.concatenate(features)
        info = {}

        return self.state, info


env = Robot()
env.set_test_cases(test_cases, existing_lines)
env = NormalizeActionWrapper(env)


# env = DummyVecEnv([lambda: env])

# state, norm_state = env.reset()

agent = SAC.load("sac_checkpoints_13_06/sac_latest.zip", env=env)



# Determine how many episodes are already written


# Evaluate remaining episodes
for i in range(existing_lines, len(test_cases)):
    obs, info = env.reset()
    total_reward = 0
    done = False

    while not done:
        with torch.no_grad():
            action, _ = agent.predict(obs, deterministic=True)
        obs, reward, done, info = env.step(action)
        total_reward += reward

    # Save to CSV: 195 obs + 1 reward = 196 columns
    episode_data = list(obs) + [total_reward]

    with open(results_path, mode='a', newline='') as file:
        writer = csv.writer(file, delimiter=';')
        formatted_row = [format_float(x) if isinstance(x, (float, np.floating)) else x for x in episode_data]
        writer.writerow(formatted_row)

    print(f"Episode {i+1} done")





