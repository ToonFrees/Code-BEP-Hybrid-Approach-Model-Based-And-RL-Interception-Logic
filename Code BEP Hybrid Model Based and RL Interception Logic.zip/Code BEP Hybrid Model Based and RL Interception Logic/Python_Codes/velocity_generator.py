import random
import math


def generate_velocity(max_magnitude):
    while True:
        vx = random.uniform(-max_magnitude, max_magnitude)
        vy = random.uniform(-max_magnitude, max_magnitude)
        vz = 0  # Always 0 in z-direction

        magnitude = math.sqrt(vx ** 2 + vy ** 2 + vz ** 2)

        if magnitude < max_magnitude:
            return [vx, vy, vz]


