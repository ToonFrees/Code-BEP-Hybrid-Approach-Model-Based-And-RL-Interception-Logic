test_cases = [
    {
        "p_initial": [0.0, 0.0, 0.0],
        "v_initial": [0.0, 0.0, 0.0],
        "p_input_target": [2.0, 2.0, 0.0],
        "p_initial_ball": [1.0, 1.0],
        "v_initial_ball": [0.1, -0.1]
    },
    {
        "p_initial": [-3.0, 5.0, 0.0],
        "v_initial": [0.0, 0.0, 0.0],
        "p_input_target": [3.0, -5.0, 0.0],
        "p_initial_ball": [0.0, 0.0],
        "v_initial_ball": [-0.1, 0.2]
    },
    ...
]