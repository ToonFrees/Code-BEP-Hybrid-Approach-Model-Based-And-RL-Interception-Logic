import math
import random

def random_point_in_circle(origin, radius):
    while True:
        # Generate a random angle and radius
        angle = random.uniform(0, 2 * math.pi)
        r = math.sqrt(random.uniform(0, radius))

        # Convert to Cartesian coordinates
        x = origin[0] + r * math.cos(angle)
        y = origin[1] + r * math.sin(angle)

        # Check bounds
        if -4 <= x <= 4 and -6 <= y <= 6:
            return [x, y, 0]