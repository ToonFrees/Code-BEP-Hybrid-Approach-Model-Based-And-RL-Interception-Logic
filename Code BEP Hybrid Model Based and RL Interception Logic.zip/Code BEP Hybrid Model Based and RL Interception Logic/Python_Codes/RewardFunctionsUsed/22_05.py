import numpy as np
import math

def reward_function(state, action, prev_action, timestep):
    state = np.asarray(state).flatten()
    action = np.asarray(action).flatten()
    prev_action = np.asarray(prev_action).flatten()
    # penalty_hitting_obstacle = 0
    penalty_traj_hitting_obstacle = 0
    ball_reached_reward = 0.0
    reward_traj_hitting_target = 0.0
    angle_traj_reward = 0.0
    magnitude_robot_vs_action = 0.0
    penalty_robot_vs_target_angle = 0.0

    distance = np.linalg.norm(state[40:42] - state[22:24])
    robot_pos = state[22:24]

    #Obstacle penalty
    for i in range(9):  # 9 opponents
        active = state[31 + i]
        if active == 1:
            opponent_pos = state[2 * i : 2 * i + 2]  # x and y
            # dist = np.linalg.norm(opponent_pos - robot_pos)
            # if dist < 0.25:
            #     penalty_hitting_obstacle = -2
            for j in range(20):
                traj_pos = state[2*j + 46 : 2*j + 48]
                dist_opp_traj = np.linalg.norm(traj_pos - opponent_pos)
                if dist_opp_traj < 0.25:
                    penalty_traj_hitting_obstacle = -0.1
    sharpness_distance = 3

    #distance_coefficient_distance_reward = 0.5 * (1 + np.tanh(sharpness_distance * (distance - 1)))
    #Distance reward based on planned trajectory
    distance_traj_5 = np.linalg.norm(state[54:56] - state[40:42])
    relative_distance = distance - distance_traj_5
    if relative_distance >= 0:
        distance_reward = (relative_distance)/100
    else:
        distance_reward = (relative_distance)/10

    #Trajectory should be on the ball
    sharpness_trajectory = 10
    distance_coefficient_trajectory = 0.5 * (1 + np.tanh(sharpness_trajectory * (distance - 1)))
    for j in range(20):
        traj_pos = state[2 * j + 46: 2 * j + 48]
        traj_vel = state[2 * j + 86: 2 * j + 88]
        dist_ball_traj = np.linalg.norm(traj_pos - state[40:42])
        min_traj_vel = np.array(-traj_vel).ravel()
        ball_velocity_variance = np.array(state[42:44])
        dot_prod_traj = np.dot(min_traj_vel, ball_velocity_variance)
        norm_traj = np.linalg.norm(min_traj_vel)
        norm_vel_target = np.linalg.norm(ball_velocity_variance)
        if norm_traj == 0:
            cos_angle_traj = 0
        else:
            cos_angle_traj = np.clip(dot_prod_traj / (norm_traj*norm_vel_target), -1, 1)
        angle_traj = np.arccos(cos_angle_traj)
        if dist_ball_traj < 0.2:
            reward_traj_hitting_target += 0.03
            if abs(angle_traj) > np.pi / 8:
                angle_traj_reward += 0
            else:
                angle_traj_reward += 0.07 * np.cos(3 * angle_traj) ** 2
            if j>0:

                for p in range(j-1):
                    traj_pos_further = state[2 * p + 46: 2 * p + 48]
                    dist_ball_traj_further = np.linalg.norm(traj_pos_further - (state[40:42]+5*0.02*state[42:44]))
                    traj_vel_further = state[2 * p + 86: 2 * p + 88]
                    min_traj_vel_further = np.array(-traj_vel_further).ravel()
                    ball_velocity_variance_further = np.array(state[42:44])
                    dot_prod_traj_further = np.dot(min_traj_vel_further, ball_velocity_variance_further)
                    norm_traj_further = np.linalg.norm(min_traj_vel_further)
                    norm_vel_target_further = np.linalg.norm(ball_velocity_variance_further)
                    if norm_traj_further == 0:
                        cos_angle_traj_further = 0
                    else:
                        cos_angle_traj_further = np.clip(dot_prod_traj_further / (norm_traj_further * norm_vel_target_further), -1, 1)
                    angle_traj_further = np.arccos(cos_angle_traj_further)
                    if dist_ball_traj_further < 0.2:
                        reward_traj_hitting_target += 0.07
                        if abs(angle_traj_further) > np.pi / 8:
                            angle_traj_reward += 0
                        else:
                            angle_traj_reward += 0.3 * np.cos(3 * angle_traj) ** 2






    #Ball reached Reward
    if distance < 0.2:
        ball_reached_reward = 12.0


    #ETA reward
    vmax = 4
    if state[187] == 0:
        eta_reward = 0.0  # Or some default penalty
    else:
        eta_denominator = max(state[187], 1e-1) # avoid near-zero
        eta_fastest = distance / vmax
        # eta_reward = -(1 - 0.5*math.e ** (eta_fastest / eta_denominator))
        ratio = eta_denominator / max(eta_fastest, 1e-1)
        eta_penalty = math.tanh(ratio - 1)  # zero when equal
        eta_reward = (1 - eta_penalty)/10  # reward is max when eta_denominator ≈ eta_fastest

    #Angle Reward
    if distance < 0.2:
        sharpness_angle = 4
        distance_coefficient = 0.5 * (1 - np.tanh(sharpness_angle * (distance - 2.5)))
        v1 = np.array([action[0], action[1]])
        v1 = -v1
        v2 = np.array([state[42], state[43]])

        dot_prod = np.dot(v1.ravel(), v2.ravel())
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)

        if norm_v1 == 0 or norm_v2 == 0:
            cos_theta = 0  # or handle it in a way that suits your needs
        else:
            cos_theta = np.clip(dot_prod / (norm_v1 * norm_v2), -1.0, 1.0)


        angle = np.arccos(cos_theta)
        if abs(angle) > np.pi / 8:
                angle_reward = 0
        else:
            angle_reward = 8 * np.cos(3 * angle) ** 2

    else:
        angle_reward = 0
    # Cosine-based smooth bell shape

    #penalty each timestep
    if timestep < 1400:
        penalty_each_timestep = -(math.exp(0.01 * timestep) - 1) / ((math.exp(10) - 1)*100)
    else:
        penalty_each_timestep = -1

    #Reward Slow Target Velocity when close
    if distance < 0.2:
        sharpness_angle = 10
        # distance_coefficient_slow_velocity = 0.5 * (1 - np.tanh(sharpness_angle * (distance - 1)))
        magnitude_target_velocity = np.linalg.norm(state[25:27])
        reward_slow_target_velocity = -0.5*magnitude_target_velocity

    else:
        reward_slow_target_velocity = 0





    #Penalyze differentiating a lot in target velocity near the end
    sharpness_action_angle = 10
    distance_coefficient_action = 0.5 * (1 - np.tanh(sharpness_action_angle * (distance - 1.5)))
    prev_action_vector = np.array([prev_action[0], prev_action[1]])
    action_vector = np.array([action[0], action[1]])

    dot_prod_action = np.dot(prev_action_vector.ravel(), action_vector.ravel())
    norm_prev_action = np.linalg.norm(prev_action_vector)
    norm_action = np.linalg.norm(action_vector)


    if norm_prev_action == 0 or norm_action == 0:
        cos_theta_action = 0  # or handle it in a way that suits your needs
        reward_magnitude_action = 0
    else:
        cos_theta_action = np.clip(dot_prod_action / (norm_prev_action * norm_action), -1.0, 1.0)
        reward_magnitude_action = -0.05 * (norm_action - norm_prev_action)**2


    angle_action = np.arccos(cos_theta_action)
    angle_reward_action = 0.1*np.exp(-5 * angle_action**2)

    final_angle_reward_action = angle_reward_action * distance_coefficient_action

    #Penalty for differing from target velocity when hitting ball
    if distance < 0.2:
        robot_vel = state[25:27]
        dot_prod_angle = np.dot(robot_vel.ravel(), action.ravel())
        norm_robot_vel = np.linalg.norm(robot_vel)
        norm_action = np.linalg.norm(action)
        if norm_robot_vel == 0:
            cos_theta_robot_vs_action = 0
            magnitude_robot_vs_action = 0
        else:
            cos_theta_robot_vs_action = np.clip(dot_prod_angle / (norm_robot_vel * norm_action), -1, 1)
            magnitude_robot_vs_action = -0.5*abs(norm_robot_vel-norm_action)
        robot_vs_action_angle = np.arccos(cos_theta_robot_vs_action)
        penalty_robot_vs_target_angle = -3 * np.cos(3 * robot_vs_action_angle) ** 2



    # print(final_angle_reward_action, reward_slow_target_velocity, reward_traj_hitting_target, ball_reached_reward, angle_reward_action, angle_reward, eta_reward, distance_reward, reward_slow_target_velocity, penalty_traj_hitting_obstacle)


    reward = final_angle_reward_action + magnitude_robot_vs_action + penalty_robot_vs_target_angle + reward_magnitude_action + angle_traj_reward + reward_traj_hitting_target + ball_reached_reward + angle_reward + eta_reward + distance_reward + reward_slow_target_velocity + penalty_traj_hitting_obstacle + penalty_each_timestep
    return reward