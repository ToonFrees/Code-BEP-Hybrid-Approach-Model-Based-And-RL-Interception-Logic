import numpy as np
import math

def angle_between(v1, v2):
    # Compute dot product
    dot = np.dot(v1, v2)

    # Compute magnitudes
    mag1 = np.linalg.norm(v1)
    mag2 = np.linalg.norm(v2)

    # Prevent division by zero
    if mag1 == 0 or mag2 == 0:
        cos_theta = 0
    else:
        cos_theta = max(-1, min(1, dot / (mag1 * mag2)))
    # Clamp value inside [-1, 1] to avoid domain errors from floating point rounding


    # Return angle in radians
    return math.acos(cos_theta)