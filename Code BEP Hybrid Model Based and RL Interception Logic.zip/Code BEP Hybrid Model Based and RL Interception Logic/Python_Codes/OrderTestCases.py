import numpy as np
import pickle
import csv

# Load the test cases from the pickle file
with open("test_cases_new.pickle", "rb") as f:
    test_cases = pickle.load(f)

# Helper functions to calculate magnitude and direction (angle)
def vector_magnitude(vec):
    return np.linalg.norm(vec)

def vector_direction(vec):
    if len(vec) == 2:
        return np.arctan2(vec[1], vec[0])
    elif len(vec) == 3:
        return np.arctan2(vec[1], vec[0])  # Project 3D onto 2D XY-plane
    else:
        return None

# Prepare rows for CSV
csv_rows = []
for case in test_cases:
    ball_pos = case["p_initial_ball"]         # [x, y]
    ball_vel = case["v_initial_ball"]         # [vx, vy]
    robot_pos = case["p_initial"]             # [x, y, z]
    robot_vel = case["v_initial"]             # [vx, vy, vz]

    ball_mag = vector_magnitude(ball_vel)
    ball_dir = vector_direction(ball_vel)
    robot_mag = vector_magnitude(robot_vel)
    robot_dir = vector_direction(robot_vel)

    # Create a row with each component in its own column
    row = [
        ball_pos[0], ball_pos[1],
        round(ball_mag, 3),
        round(ball_dir/np.pi, 5) if ball_dir is not None else "NA",
        robot_pos[0], robot_pos[1], robot_pos[2],
        round(robot_mag, 3),
        round(robot_dir/np.pi, 5) if robot_dir is not None else "NA"
    ]

    csv_rows.append(row)

# Write to CSV file
csv_filename = "episode_summary_extra_cases_2.csv"
with open(csv_filename, mode="w", newline="") as csvfile:
    writer = csv.writer(csvfile, delimiter=';')  # ← Use semicolon here
    writer.writerow([
        "Ball Pos X", "Ball Pos Y", "Ball Velocity Magnitude", "Ball Direction (rad)",
        "Robot Pos X", "Robot Pos Y", "Robot Pos Z", "Robot Velocity Magnitude", "Robot Direction (rad)"
    ])
    writer.writerows(csv_rows)
