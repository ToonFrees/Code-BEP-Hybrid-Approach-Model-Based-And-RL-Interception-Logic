clear all; close all; clc;

data = readmatrix("evaluation_results_agent_final.csv", "DecimalSeparator",",");
extra_data = readmatrix("evaluation_results_agent_final_one_case.csv", "DecimalSeparator",",");

initial_data = readmatrix("episode_summary.csv", "Delimiter", ";");
initial_data_new_case = readmatrix("episode_summary_new_case.csv", "Delimiter", ";");

extra_velocity_data = readmatrix("evaluation_results_agent_final_velocity.csv", "DecimalSeparator", ",");
extra_initial_velocity_data = readmatrix("episode_summary_new_case_velocity.csv", "Delimiter", ";");

extra_extra_velocity_data = readmatrix("evaluation_results_agent_final_velocity_extra.csv", "DecimalSeparator", ",");
extra_extra_initial_velocity_data = readmatrix("episode_summary_new_case_velocity_1.csv", "Delimiter", ";");

extra_cases_data = readmatrix("evaluation_results_agent_final_extra_cases.csv", "DecimalSeparator", ",");
extra_cases_initial_data = readmatrix("episode_summary_extra_cases.csv", "Delimiter", ";");

extra_case_2_data = readmatrix("evaluation_results_agent_final_extra_cases_2.csv", "DecimalSeparator", ",");
extra_cases_2_initial_data = readmatrix("episode_summary_extra_cases_2.csv", "Delimiter", ";");


new_data = [data(1:255,:)
    extra_extra_velocity_data
    extra_velocity_data
    extra_case_2_data
    extra_cases_data(1:298,:)
    data(256:465,:)
    extra_data
    data(571:length(data), :)
    extra_cases_data(299:length(extra_cases_data),:)];

new_initial_data = [initial_data(1:255,:)
    extra_extra_initial_velocity_data
    extra_initial_velocity_data
    extra_cases_2_initial_data
    extra_cases_initial_data(1:298,:)
    initial_data(256:465,:)
    initial_data_new_case
    initial_data(571:length(initial_data), :)
    extra_cases_initial_data(299:length(extra_cases_initial_data),:)];

new_data_with_robot_velocity = new_data;
new_initial_data_with_robot_velocity = new_initial_data;

% Create a logical mask where the 8th column is NOT equal to 1
mask = new_initial_data(:, 8) ~= 1;

% Apply the mask to filter both datasets
new_initial_data = new_initial_data(mask, :);
new_data = new_data(mask, :);


disp(length(new_data));
disp(length(new_initial_data));

save('new_data.mat', 'new_data');
save('new_initial_data.mat', 'new_initial_data')

% Save as an Excel file
writematrix(new_data, 'new_data.csv');
writematrix(new_initial_data, 'new_initial_data.csv')