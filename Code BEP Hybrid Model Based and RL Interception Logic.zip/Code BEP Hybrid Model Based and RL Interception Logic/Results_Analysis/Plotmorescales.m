close all; clear all; clc

%% Load Data
data = load('new_data.mat');
data = data.new_data;

initial_data = load('new_initial_data.mat');
initial_data = initial_data.new_initial_data;

%% Parameters
data = data(1:255,:);
initial_data = initial_data(1:255,:);
angle_bins = [0, 45, 90, 135, 180];
velocity_levels = [0.5, 1.5];  % only non-zero magnitudes

% Prepare result matrix
success_percentage = zeros(length(velocity_levels), length(angle_bins));
total_counts = zeros(size(success_percentage));  % for reference if needed

% Loop over velocity magnitudes
for v_idx = 1:length(velocity_levels)
    v_mag = velocity_levels(v_idx);

    % Filter data
    v_mask = abs(initial_data(:,3) - v_mag) < 1e-3;  % Avoid floating point issues
    filtered_data_angle = data(v_mask, :);
    filtered_initial_angle = initial_data(v_mask, :);

    % Limit rows if needed
    N = min(255, size(filtered_initial_angle, 1));
    filtered_data_angle = filtered_data_angle(1:N, :);
    filtered_initial_angle = filtered_initial_angle(1:N, :);

    % Compute angles
    num_samples = N;
    angles_deg = zeros(num_samples,1);

    for i = 1:num_samples
        ball_pos = filtered_initial_angle(i, 1:2);
        robot_pos = filtered_initial_angle(i, 5:6);
        v1 = robot_pos - ball_pos;

        theta = filtered_initial_angle(i, 4)*pi;
        v2 = [cos(theta), sin(theta)];

        dot_prod = dot(v1, v2);
        angle_rad = acos(dot_prod / (norm(v1) * norm(v2)));
        angles_deg(i) = rad2deg(angle_rad);
    end

    % Loop over angle bins
    for a_idx = 1:length(angle_bins)
        angle_bin = angle_bins(a_idx);
        in_bin = round(angles_deg) == angle_bin;
        bin_data = filtered_data_angle(in_bin, :);
        total_counts(v_idx, a_idx) = sum(in_bin);

        cond1 = bin_data(:,1) >= -4 & bin_data(:,1) <= 4;
        cond2 = bin_data(:,2) >= -6 & bin_data(:,2) <= 6;
        cond3 = bin_data(:,167) < 3000;

        success_percentage(v_idx, a_idx) = ...
            100 * sum(cond1 & cond2 & cond3) / max(1, sum(in_bin));
    end
end


[X, Y] = meshgrid(angle_bins, velocity_levels);
figure;
surf(X, Y, success_percentage);
xlabel('Angle (degrees)');
ylabel('Velocity Magnitude (m/s)');
zlabel('Success Rate (%)');
title('Success Rate vs Angle and Velocity Magnitude');
colorbar;
view(135, 30); % Better viewing angle


figure;
bar3(success_percentage');
set(gca, 'XTickLabel', string(velocity_levels));
set(gca, 'YTickLabel', angle_bins);
xlabel('Angle (degrees)');
ylabel('Velocity Magnitude (m/s)');
zlabel('Success Rate (%)');
title('Success Rate vs Angle and Velocity Magnitude');
grid on;


%% Based on intial robot pos

%% Parameters
data = data(1:255,:);
initial_data = initial_data(1:255,:);
angle_bins = [0, 45, 90, 135, 180];
initial_positions = [
    -1.5, 0;
    -3, 0;
     0, 2;
     0, 4;
     0, 5.5
];  % only non-zero magnitudes

% Prepare result matrix
success_percentage = zeros(length(initial_positions), length(angle_bins));
total_counts = zeros(size(success_percentage));  % for reference if needed

% Loop over velocity magnitudes
for v_idx = 1:length(initial_positions)
    v_mag = initial_positions(v_idx, :);

    % Filter data
    v_mask = abs(initial_data(:,5) - v_mag(1)) < 1e-3 & abs(initial_data(:,6) - v_mag(2)) < 1e-3;
    filtered_data_angle_position = data(v_mask, :);
    filtered_initial_angle_position = initial_data(v_mask, :);

    % Limit rows if needed
    N = min(255, size(filtered_initial_angle_position, 1));
    filtered_data_angle_position = filtered_data_angle_position(1:N, :);
    filtered_initial_angle_position = filtered_initial_angle_position(1:N, :);

    % Compute angles
    num_samples = N;
    angles_deg_position = zeros(num_samples,1);

    for i = 1:num_samples
        ball_pos = filtered_initial_angle_position(i, 1:2);
        robot_pos = filtered_initial_angle_position(i, 5:6);
        v1 = robot_pos - ball_pos;

        theta = filtered_initial_angle_position(i, 4)*pi;
        v2 = [cos(theta), sin(theta)];

        dot_prod = dot(v1, v2);
        angle_rad = acos(dot_prod / (norm(v1) * norm(v2)));
        angles_deg_position(i) = rad2deg(angle_rad);
    end

    % Loop over angle bins
    for a_idx = 1:length(angle_bins)
        angle_bin = angle_bins(a_idx);
        in_bin = round(angles_deg_position) == angle_bin;
        bin_data = filtered_data_angle_position(in_bin, :);
        total_counts(v_idx, a_idx) = sum(in_bin);

        cond1 = bin_data(:,1) >= -4 & bin_data(:,1) <= 4;
        cond2 = bin_data(:,2) >= -6 & bin_data(:,2) <= 6;
        cond3 = bin_data(:,167) < 3000;

        success_percentage(v_idx, a_idx) = ...
            100 * sum(cond1 & cond2 & cond3) / max(1, sum(in_bin));
    end
end
initial_distances = [1.5, 3, 2, 4.5, 5.5];

[X, Y] = meshgrid(angle_bins, initial_distances);
figure;
surf(X, Y, success_percentage);
xlabel('Angle (degrees)');
ylabel('Position (m/s)');
zlabel('Success Rate (%)');
title('Success Rate vs Angle and Velocity Magnitude');
colorbar;
view(135, 30); % Better viewing angle


figure;
bar3(success_percentage');
set(gca, 'XTickLabel', string(initial_distances));
set(gca, 'YTickLabel', angle_bins);
xlabel('Angle (degrees)');
ylabel('Velocity Magnitude (m/s)');
zlabel('Success Rate (%)');
title('Success Rate vs Angle and Velocity Magnitude');
grid on;