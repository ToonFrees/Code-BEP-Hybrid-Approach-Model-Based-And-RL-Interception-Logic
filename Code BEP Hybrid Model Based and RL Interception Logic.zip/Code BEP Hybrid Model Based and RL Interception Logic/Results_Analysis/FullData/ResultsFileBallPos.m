close all; clear all; clc

%All data from ball pos [0,0], [1,0], [0,-1], [-2,3], [3,0], [2,-3], [0,-4]
%Use all robot pos [-3,0], [-1.5,0], [0,2]
%All bal velocities {0, 0.5, 1, 1.5}
%% Load Data
data =load('new_data.mat');
data = data.new_data;

initial_data = load('new_initial_data.mat');
initial_data = initial_data.new_initial_data;

mask_robot_pos_cl = initial_data(:,5) == -3 & initial_data(:,6) == 0 | initial_data(:,5) == -1.5 & initial_data(:,6) == 0 | initial_data(:,5) == 0 & initial_data(:,6) == 2;

mask_velocity_cl = initial_data(:, 3) == 0 | ...
                   initial_data(:, 3) == 0.5 | ...
                   initial_data(:, 3) == 1 | ...
                   initial_data(:, 3) == 1.5;
% mask_velocity_not_cl = initial_data(:, 3) == 2.5;

combined_mask_cl = mask_robot_pos_cl & mask_velocity_cl;

filtered_data = data(combined_mask_cl, :);
filtered_initial_data = initial_data(combined_mask_cl, :);





%% 3D plot


% Define unique initial ball positions manually (replace with actual values if known)
initial_positions = [
     0, 0;
     1, 0;
     0, -1;
     -2, 3;
     3, 0;
     2, -3;
     0, -4
];

num_positions = size(initial_positions, 1);
success_counts = zeros(num_positions, 1);
total_counts = zeros(num_positions, 1);

% Loop through each position
for i = 1:num_positions
    pos = initial_positions(i, :);
    
    % Find all rows with this initial position (tolerance for floating point)
    mask = abs(filtered_initial_data(:,1) - pos(1)) < 1e-3 & abs(filtered_initial_data(:,2) - pos(2)) < 1e-3;
    
    % Filter corresponding data
    data_pos = filtered_data(mask, :);
    
    % Total count
    total_counts(i) = size(data_pos, 1);

    % Success conditions
    cond1 = data_pos(:,1) >= -4 & data_pos(:,1) <= 4;
    cond2 = data_pos(:,2) >= -6 & data_pos(:,2) <= 6;
    cond3 = data_pos(:,167) < 3000;
    
    success_counts(i) = sum(cond1 & cond2 & cond3);
end

% Calculate percentages
success_percentage = 100 * success_counts ./ max(total_counts, 1);

% Plotting
figure;
bar(success_percentage, 0.5);
xticklabels({
    sprintf('(%g, %g)', initial_positions(1,:)), ...
    sprintf('(%g, %g)', initial_positions(2,:)), ...
    sprintf('(%g, %g)', initial_positions(3,:)), ...
    sprintf('(%g, %g)', initial_positions(4,:)), ...
    sprintf('(%g, %g)', initial_positions(5,:)), ...
    sprintf('(%g, %g)', initial_positions(6,:)), ...
    sprintf('(%g, %g)', initial_positions(7,:))
});
xlabel('Initial Ball Position (x, y)');
ylabel('Success Rate (%)');
title('Success Rate by Initial Ball Position');
ylim([0 100]);
grid on;

for i = 1:length(success_percentage)
    val = success_percentage(i);
    text(i, val + 2, sprintf('%.1f%%', val), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', 10);
end




