close all; clear all; clc

%% Load Data


data =load('new_data.mat');
data = data.new_data;

initial_data = load('new_initial_data.mat');
initial_data = initial_data.new_initial_data;

successful_mask = data(:,1) >= -4 & data(:,1) <= 4 & data(:,2) >= -6 & data(:,2) <= 6 & data(:,167) < 3000;
distances = sqrt((initial_data(:,1) - initial_data(:,5)).^2 + ...
                 (initial_data(:,2) - initial_data(:,6)).^2);

% Create mask for distance > 3.5
mask_distance = distances < 3;

mask_velocity_cl = initial_data(:, 3) == 0 | ...
                   initial_data(:, 3) == 0.5 | ...
                   initial_data(:, 3) == 1 | ...
                   initial_data(:, 3) == 1.5;


combined_mask = successful_mask & mask_distance & mask_velocity_cl;
combined_mask_data = mask_distance & mask_velocity_cl;
combined_mask_data_not_cl = ~combined_mask_data;
combined_mask_not_cl = successful_mask & combined_mask_data_not_cl;

successful_data = data(successful_mask, :);
success_rate = 100 * size(successful_data,1)/size(data,1);
fprintf('Overall success percentage: %.2f%%\n', success_rate);

data_cl = data(combined_mask_data,:);
successful_data_cl = data(combined_mask, :);
success_rate_cl = 100 * size(successful_data_cl,1)/size(data_cl,1);
fprintf('CL success percentage: %.2f%%\n', success_rate_cl);

data_cl_not_cl = data(combined_mask_data_not_cl,:);
successful_data_cl_not_cl = data(combined_mask_not_cl, :);
success_rate_cl_not_cl = 100 * size(successful_data_cl_not_cl,1)/size(data_cl_not_cl,1);
fprintf('Not CL success percentage: %.2f%%\n', success_rate_cl_not_cl);


% % Apply success conditions
% cond1 = data(:,1) >= -4 & data(:,1) <= 4;
% cond2 = data(:,2) >= -6 & data(:,2) <= 6;
% cond3 = data(:,167) < 3000;
% 
% % Combine all conditions
% success = cond1 & cond2 & cond3;
% 
% % Compute percentage
% total_rows = size(data, 1);
% num_success = sum(success);
% success_percentage = 100 * num_success / total_rows;
% 
% % Display result
% fprintf('Overall success percentage: %.2f%%\n', success_percentage);

% Find indices where initial velocity is non-zero
nonzero_idx = find(initial_data(:,3) == 0);

% Filter corresponding rows from data
filtered_data = data(nonzero_idx, :);

% Apply success conditions
cond1 = filtered_data(:,1) >= -4 & filtered_data(:,1) <= 4;
cond2 = filtered_data(:,2) >= -6 & filtered_data(:,2) <= 6;
cond3 = filtered_data(:,167) < 3000;

% Combine all conditions
success = cond1 & cond2 & cond3;

% Compute percentage
total_rows = size(filtered_data, 1);
num_success = sum(success);
success_percentage = 100 * num_success / total_rows;

% Display result
fprintf('Success percentage (non-zero velocity): %.2f%%\n', success_percentage);

%% Percentage of succes based on magnitude velocity
velocity_levels = [0, 0.5, 1, 1.5, 2.5];

success_counts_velocity = zeros(size(velocity_levels));
total_counts_velocity = zeros(size(velocity_levels));
filtered_data = data;
filtered_initial_data = initial_data;


for idx = 1:length(velocity_levels)
    vel = velocity_levels(idx);

    % Find rows with this velocity level
    rows = find(filtered_initial_data(:,3) == vel);

    % Total number of rows with this velocity
    total_counts_velocity(idx) = length(rows);

        % Apply success conditions
    sub_data_velocity = filtered_data(rows, :);

    cond1_velocity = sub_data_velocity(:, 1) >= -4 & sub_data_velocity(:, 1) <= 4;
    cond2_velocity = sub_data_velocity(:, 2) >= -6 & sub_data_velocity(:, 2) <= 6;
    cond3_velocity = sub_data_velocity(:, 167) < 3000;

    % Count successes
    success_counts_velocity(idx) = sum(cond1_velocity & cond2_velocity & cond3_velocity);
end

% Calculate success percentages
success_percentages_velocity = 100 * success_counts_velocity ./ total_counts_velocity;

%% Plotting
figure;
bar(velocity_levels, success_percentages_velocity, 0.4);
xlabel('Initial Velocity Magnitude (m/s)');
ylabel('Success Rate (%)');
title('Policy Success Rate by Initial Velocity Magnitude');
ylim([0 100]);
grid on;

%% Percentage of Succes based angle initial pos

% Only consider rows with non-zero ball velocity
nonzero_idx = find(initial_data(:,3) > 0);
filtered_data_angle = data(nonzero_idx, :);
% filtered_data_angle = filtered_data_angle(1:255,:);
filtered_initial_angle = initial_data(nonzero_idx, :);
% filtered_initial_angle = filtered_initial_angle(1:255,:);

% Compute angles
num_samples = length(filtered_initial_angle);
angles_deg = zeros(num_samples,1);

for i = 1:num_samples
    % Ball position
    ball_pos = filtered_initial_angle(i, 1:2);
    
    % Robot position
    robot_pos = filtered_initial_angle(i, 5:6);
    
    % Vector from ball to robot
    v1 = robot_pos - ball_pos;
    
    % Ball velocity direction
    angle = filtered_initial_angle(i, 4)*pi; % in radians
    v2 = [cos(angle), sin(angle)];
    
    % Compute angle between vectors
    dot_prod = dot(v1, v2);
    angle_rad = acos(dot_prod / (norm(v1) * norm(v2)));
    angles_deg(i) = rad2deg(abs(angle_between(v1,v2))); % between 0 and 180
end

% Bin angles: [0-30], [30-60], ..., [150-180]
edges = 0:30:210;
angles = [0,45,90,135,180];
centers = edges(1:end-1) + 15;
num_bins = length(centers);
success_counts = zeros(1, length(angles));
total_counts = zeros(1, length(angles));

for j = 1:length(angles)
    % Indices in this angle bin
    angle_used = angles(j);
    in_bin = round(angles_deg) == angle_used;
    bin_data = filtered_data_angle(in_bin, :);
    total_counts(j) = sum(in_bin);
    
    % Success criteria
    cond1_angle = bin_data(:,1) >= -4 & bin_data(:,1) <= 4;
    cond2_angle = bin_data(:,2) >= -6 & bin_data(:,2) <= 6;
    cond3_angle = bin_data(:,167) < 3000;
    
    success_counts(j) = sum(cond1_angle & cond2_angle & cond3_angle);
end

% Calculate percentage
success_percentage = 100 * success_counts ./ max(total_counts,1);

% Plot
figure;
bar(angles, success_percentage, 'BarWidth', 1);
xlabel('Angle Between Ball Velocity and Ball→Robot Direction (degrees)');
ylabel('Success Rate (%)');
title('Success Rate vs Ball-Robot Angle (Non-zero Ball Velocity)');
ylim([0 100]);
grid on;

%% 3D plot


% Define unique initial ball positions manually (replace with actual values if known)
initial_positions = [
    0, 0;
    -2, 3;
     2, -3;
     3, 0;
     0, -4
];

num_positions = size(initial_positions, 1);
success_counts = zeros(num_positions, 1);
total_counts = zeros(num_positions, 1);

% Loop through each position
for i = 1:num_positions
    pos = initial_positions(i, :);
    
    % Find all rows with this initial position (tolerance for floating point)
    mask = abs(initial_data(:,1) - pos(1)) < 1e-3 & abs(initial_data(:,2) - pos(2)) < 1e-3;
    
    % Filter corresponding data
    data_pos = data(mask, :);
    
    % Total count
    total_counts(i) = size(data_pos, 1);

    % Success conditions
    cond1 = data_pos(:,1) >= -4 & data_pos(:,1) <= 4;
    cond2 = data_pos(:,2) >= -6 & data_pos(:,2) <= 6;
    cond3 = data_pos(:,167) < 3000;
    
    success_counts(i) = sum(cond1 & cond2 & cond3);
end

% Calculate percentages
success_percentage = 100 * success_counts ./ max(total_counts, 1);

% Plotting
figure;
bar(success_percentage, 0.5);
xticklabels({
    sprintf('(%g, %g)', initial_positions(1,:)), ...
    sprintf('(%g, %g)', initial_positions(2,:)), ...
    sprintf('(%g, %g)', initial_positions(3,:)), ...
    sprintf('(%g, %g)', initial_positions(4,:))
});
xlabel('Initial Ball Position (x, y)');
ylabel('Success Rate (%)');
title('Success Rate by Initial Ball Position');
ylim([0 100]);
grid on;

for i = 1:length(success_percentage)
    val = success_percentage(i);
    text(i, val + 2, sprintf('%.1f%%', val), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'bottom', ...
        'FontSize', 10);
end

%% Parameters
angle_bins = [0, 45, 90, 135, 180];
velocity_levels = [0.5, 1.5];  % only non-zero magnitudes

% Prepare result matrix
success_percentage = zeros(length(velocity_levels), length(angle_bins));
total_counts = zeros(size(success_percentage));  % for reference if needed

% Loop over velocity magnitudes
for v_idx = 1:length(velocity_levels)
    v_mag = velocity_levels(v_idx);

    % Filter data
    v_mask = abs(initial_data(:,3) - v_mag) < 1e-3;  % Avoid floating point issues
    filtered_data_angle = data(v_mask, :);
    filtered_initial_angle = initial_data(v_mask, :);

    % Limit rows if needed
    N = size(filtered_initial_angle, 1);
    filtered_data_angle = filtered_data_angle(1:N, :);
    filtered_initial_angle = filtered_initial_angle(1:N, :);

    % Compute angles
    num_samples = N;
    angles_deg = zeros(num_samples,1);

    for i = 1:num_samples
        ball_pos = filtered_initial_angle(i, 1:2);
        robot_pos = filtered_initial_angle(i, 5:6);
        v1 = robot_pos - ball_pos;

        theta = filtered_initial_angle(i, 4)*pi;
        v2 = [cos(theta), sin(theta)];

        dot_prod = dot(v1, v2);
        angle_rad = acos(dot_prod / (norm(v1) * norm(v2)));
        angles_deg(i) = rad2deg(angle_rad);
    end

    % Loop over angle bins
    for a_idx = 1:length(angle_bins)
        angle_bin = angle_bins(a_idx);
        in_bin = round(angles_deg) == angle_bin;
        bin_data = filtered_data_angle(in_bin, :);
        total_counts(v_idx, a_idx) = sum(in_bin);

        cond1_angle = bin_data(:,1) >= -4 & bin_data(:,1) <= 4;
        cond2_angle = bin_data(:,2) >= -6 & bin_data(:,2) <= 6;
        cond3_angle = bin_data(:,167) < 3000;

        success_percentage(v_idx, a_idx) = ...
            100 * sum(cond1_angle & cond2_angle & cond3_angle) / max(1, sum(in_bin));
    end
end
