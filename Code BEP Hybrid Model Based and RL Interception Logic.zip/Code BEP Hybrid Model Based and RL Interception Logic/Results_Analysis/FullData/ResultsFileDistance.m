close all; clear all; clc

%All data from ball pos [0,0], [1,0], [0,-1], [-2,3], [3,0], [2,-3], [0,-4]
%Use all robot pos [-3,0], [-1.5,0], [0,2]
%All bal velocities {0, 0.5, 1, 1.5}
%% Load Data
data =load('new_data.mat');
data = data.new_data;

initial_data = load('new_initial_data.mat');
initial_data = initial_data.new_initial_data;

mask_robot_pos_cl = initial_data(:,1) == 0 & initial_data(:,2) == 0 | initial_data(:,1) == 1 & initial_data(:,2) == 0 | initial_data(:,1) == 0 & initial_data(:,2) == -1 | ...
    initial_data(:,1) == 3 & initial_data(:,2) == 0 | initial_data(:,1) == 2 & initial_data(:,2) == -3 | initial_data(:,1) == 0 & initial_data(:,2) == -4 | ...
    initial_data(:,1) == -2 & initial_data(:,2) == 3;

mask_velocity_cl = initial_data(:, 3) == 0 | ...
                   initial_data(:, 3) == 0.5 | ...
                   initial_data(:, 3) == 1 | ...
                   initial_data(:, 3) == 1.5;
% mask_velocity_not_cl = initial_data(:, 3) == 2.5;

combined_mask_cl = mask_velocity_cl & mask_robot_pos_cl;

filtered_data = data(combined_mask_cl, :);
filtered_initial_data = initial_data(combined_mask_cl, :);

%% Success rate vs. initial distance between ball and robot

% Calculate Euclidean distance between initial ball and robot
ball_pos = filtered_initial_data(:, 1:2);
robot_pos = filtered_initial_data(:, 5:6);
distances = sqrt(sum((ball_pos - robot_pos).^2, 2));

% Define distance bins (you can adjust these if needed)
edges = 0.75:0.5:10.25;  % e.g., bin distances from 0 to 6 in 0.5 steps
bin_centers = edges(1:end-1) + diff(edges)/2;
num_bins = length(bin_centers);

success_counts = zeros(num_bins, 1);
total_counts = zeros(num_bins, 1);

% Loop through bins
for i = 1:num_bins
    in_bin = distances >= edges(i) & distances < edges(i+1);
    
    data_bin = filtered_data(in_bin, :);
    total_counts(i) = size(data_bin, 1);
    
    if total_counts(i) > 0
        cond1 = data_bin(:,1) >= -4 & data_bin(:,1) <= 4;
        cond2 = data_bin(:,2) >= -6 & data_bin(:,2) <= 6;
        cond3 = data_bin(:,167) < 3000;
        success_counts(i) = sum(cond1 & cond2 & cond3);
    end
end

% Calculate success percentage
success_percentage = 100 * success_counts ./ max(total_counts, 1);

%% Plotting
figure;
bar(bin_centers, success_percentage, 0.75, 'FaceColor', [0.3 0.7 0.3]);
xlabel('Initial Distance [m]', 'FontSize', 16);
ylabel('Success Rate [%]','FontSize', 16);
title('Success Rate vs Initial Distance', 'FontSize', 18);
ylim([0 100]);
set(gca, 'FontSize', 14);
grid on;

% Add text labels
% for i = 1:num_bins
%     if total_counts(i) > 0
%         text(bin_centers(i), success_percentage(i) + 2, ...
%             sprintf('%.1f%%', success_percentage(i)), ...
%             'HorizontalAlignment', 'center', ...
%             'FontSize', 9);
%     end
% end