close all; clear all; clc

%All data from ball pos [0,0], [1,0], [0,-1], [-2,3], [3,0], [2,-3], [0,-4]
%Use all robot pos [-3,0], [-1.5,0], [0,2]
%All bal velocities {0, 0.5, 1, 1.5}
%% Load Data
data =load('new_data.mat');
data = data.new_data;

initial_data = load('new_initial_data.mat');
initial_data = initial_data.new_initial_data;

successful_mask = data(:,1) >= -4 & data(:,1) <= 4 & data(:,2) >= -6 & data(:,2) <= 6 & data(:,167) < 3000;
% mask_robot_pos_cl = initial_data(:,5) == -3 & initial_data(:,6) == 0 | initial_data(:,5) == -1.5 & initial_data(:,6) == 0 | initial_data(:,5) == 0 & initial_data(:,6) == 2;
% mask_ball_pos_cl = initial_data(:,1) == -3 & initial_data(:,2) == 0 | initial_data(:,1) == -1.5 & initial_data(:,6) == 0 | initial_data(:,5) == 0 & initial_data(:,6) == 2;

mask_velocity_cl = initial_data(:, 3) == 0 | ...
                   initial_data(:, 3) == 0.5 | ...
                   initial_data(:, 3) == 1 | ...
                   initial_data(:, 3) == 1.5;
% mask_velocity_not_cl = initial_data(:, 3) == 2.5;

distances = sqrt((initial_data(:,1) - initial_data(:,5)).^2 + ...
                 (initial_data(:,2) - initial_data(:,6)).^2);

% Create mask for distance > 3.5
mask_distance = distances < 3.5;

combined_mask_cl = mask_velocity_cl & successful_mask & mask_distance;

filtered_data = data(combined_mask_cl, :);
filtered_initial_data = initial_data(combined_mask_cl, :);





%% 3D plot

%% Extract Data
angle_of_approach = (filtered_data(:,142)*180)/pi;
robot_pos = filtered_initial_data(:,5:6);
ball_pos = filtered_initial_data(:,1:2);
angles_rad = filtered_initial_data(:,4) * pi;

%% 1. Bar Plot: Angle of Approach vs Time (binned)
velocity = filtered_initial_data(:,3);
velocity_levels = [0.5, 1, 1.5];

% Preallocate result vector
mean_aoa_velocity = zeros(size(velocity_levels));

% Loop through each velocity level and compute mean AoA
for i = 1:length(velocity_levels)
    mask = velocity == velocity_levels(i);
    mean_aoa_velocity(i) = mean(angle_of_approach(mask), 'omitnan');
end

% Plotting
figure;
bar(velocity_levels, mean_aoa_velocity, 'FaceColor', [0.2 0.6 0.8]);
xlabel('Initial Speed [m/s]', 'FontSize', 16);
ylabel('Avg. Angle of Approach [degrees]', 'FontSize', 16);
title('Angle of Approach vs Initial Speed (Ball)', 'FontSize', 18);
set(gca, 'FontSize', 14)
grid on;

%% 2. Bar Plot: Angle of Approach vs Initial Distance (binned)
distances = sqrt(sum((robot_pos - ball_pos).^2, 2));
edges_dist = 0.75:0.5:3.25;
[~, ~, bin_dist] = histcounts(distances, edges_dist);
centers_dist = edges_dist(1:end-1) + diff(edges_dist)/2;

mean_aoa_dist = accumarray(bin_dist, angle_of_approach, [length(centers_dist), 1], @mean, NaN);

figure;
bar(centers_dist, mean_aoa_dist, 'FaceColor', [0.3 0.7 0.3]);
xlabel('Initial Distance [m]', 'FontSize', 16);
ylabel('Avg. Angle of Approach [degrees]', 'FontSize', 16);
title('Angle of Approach vs Initial Distance', 'FontSize', 18);
set(gca, 'FontSize', 14)
grid on;

%% 3. Bar Plot: Angle of Approach vs Vector Alignment Angle (binned)
velocity_dirs = [cos(angles_rad), sin(angles_rad)];
vec_robot_to_ball = robot_pos - ball_pos;

% Compute angle between vectors
norm_vec = sqrt(sum(vec_robot_to_ball.^2, 2));
norm_vel = sqrt(sum(velocity_dirs.^2, 2));
dot_products = sum(vec_robot_to_ball .* velocity_dirs, 2);
cos_theta = dot_products ./ (norm_vec .* norm_vel);
cos_theta = max(min(cos_theta, 1), -1);  % Clamp for numerical safety
angle_between = acosd(cos_theta);  % in degrees

edges_angle = 0:30:180;
[~, ~, bin_angle] = histcounts(angle_between, edges_angle);
centers_angle = edges_angle(1:end-1) + diff(edges_angle)/2;

mean_aoa_angle = accumarray(bin_angle, angle_of_approach, [length(centers_angle), 1], @mean, NaN);

figure;
bar(centers_angle, mean_aoa_angle, 'FaceColor', [0.8 0.4 0.4]);
xlabel('Angle Between Robot-Ball Vector and Velocity Direction (°)');
ylabel('Avg. Angle of Approach (degrees)');
title('Angle of Approach vs Vector Alignment Angle (Binned)');
grid on;


velocity_dirs = [cos(angles_rad), sin(angles_rad)];
vec_robot_to_ball = robot_pos - ball_pos;

% Compute angle between vectors
norm_vec = sqrt(sum(vec_robot_to_ball.^2, 2));
norm_vel = sqrt(sum(velocity_dirs.^2, 2));
dot_products = sum(vec_robot_to_ball .* velocity_dirs, 2);
cos_theta = dot_products ./ (norm_vec .* norm_vel);
cos_theta = max(min(cos_theta, 1), -1);  % Clamp for numerical safety
angle_between = acosd(cos_theta);  % in degrees

edges_angle = 0:45:180;
[~, ~, bin_angle] = histcounts(angle_between, edges_angle);
centers_angle = edges_angle(1:end-1) + diff(edges_angle)/2;

mean_aoa_angle = accumarray(bin_angle, angle_of_approach, [length(centers_angle), 1], @mean, NaN);

figure;
bar(centers_angle, mean_aoa_angle, 'FaceColor', [0.8 0.4 0.4]);
xlabel('Angle Between Robot-Ball Vector and Velocity Direction (°)');
ylabel('Avg. Time (s)');
title('Time till intercept vs Vector Alignment Angle (Binned)');
grid on;

% Angle between robot-ball vector and velocity direction (0–180 degrees)
edges_angle = -22.5:45:202.5;
centers_angle = edges_angle(1:end-1) + diff(edges_angle)/2;

% Assign each value to a bin (returns NaN for out-of-range)
bin_angle = discretize(angle_between, edges_angle);

% Use findgroups & splitapply (ignores NaNs)
[G, valid] = findgroups(bin_angle(~isnan(bin_angle)));
mean_angle_of_approach = splitapply(@mean, angle_of_approach(~isnan(bin_angle)), G);

% For plotting: initialize with NaNs and insert values into correct positions
mean_aoa_angle = NaN(size(centers_angle));
mean_aoa_angle(unique(bin_angle(~isnan(bin_angle)))) = mean_angle_of_approach;

% Plot
figure;
bar(centers_angle, mean_aoa_angle, 'FaceColor', [0.8 0.4 0.4]);
xlabel('Initial Angle [degrees]', 'FontSize', 16);
ylabel('Avg. Angle of Approach [degrees]', 'FontSize', 16);
title('Angle of Approach vs Initial Angle', 'FontSize', 18);
set(gca, 'FontSize', 14)
grid on;

% %% Extract Common Data
% angle_of_approach = filtered_data(:,142);
% robot_pos = filtered_initial_data(:,5:6);
% ball_pos = filtered_initial_data(:,1:2);
% angles_rad = filtered_initial_data(:,4) * pi;
% 
% %% --- First Plot: Angle of Approach vs Time (averaged by time) ---
% time = round(filtered_data(:,167) * 0.02, 3);  % Round to avoid float precision issues
% [unique_time, ~, idx_time] = unique(time);
% avg_aoa_time = accumarray(idx_time, angle_of_approach, [], @mean);
% 
% figure;
% plot(unique_time, avg_aoa_time, 'o-');
% xlabel('Time (s)');
% ylabel('Avg. Angle of Approach (degrees)');
% title('Angle of Approach vs Time');
% grid on;
% 
% %% --- Second Plot: Angle of Approach vs Initial Distance ---
% distances = sqrt(sum((robot_pos - ball_pos).^2, 2));
% distances = round(distances, 3);
% [unique_dist, ~, idx_dist] = unique(distances);
% avg_aoa_dist = accumarray(idx_dist, angle_of_approach, [], @mean);
% 
% figure;
% plot(unique_dist, avg_aoa_dist, 'o-');
% xlabel('Initial Distance Between Robot and Ball');
% ylabel('Avg. Angle of Approach (degrees)');
% title('Angle of Approach vs Initial Distance');
% grid on;
% 
% %% --- Third Plot: Angle of Approach vs Vector Angle (robot-ball vs velocity) ---
% velocity_dirs = [cos(angles_rad), sin(angles_rad)];
% vec_robot_to_ball = robot_pos - ball_pos;
% 
% norm_vec = sqrt(sum(vec_robot_to_ball.^2, 2));
% norm_vel = sqrt(sum(velocity_dirs.^2, 2));
% dot_products = sum(vec_robot_to_ball .* velocity_dirs, 2);
% cos_theta = dot_products ./ (norm_vec .* norm_vel);
% cos_theta = max(min(cos_theta, 1), -1);  % Clamp to [-1,1]
% angle_between = round(acosd(cos_theta), 3);  % Angle in degrees
% 
% [unique_angle, ~, idx_angle] = unique(angle_between);
% avg_aoa_vector_angle = accumarray(idx_angle, angle_of_approach, [], @mean);
% 
% figure;
% plot(unique_angle, avg_aoa_vector_angle, 'o-');
% xlabel('Angle Between Robot-Ball Vector and Velocity Direction (degrees)');
% ylabel('Avg. Angle of Approach (degrees)');
% title('Angle of Approach vs Vector Alignment Angle');
% grid on;


% %% First Plot: Angle of Approach vs Time
% figure;
% time = filtered_data(:,167) * 0.02;
% angle_of_approach = filtered_data(:,142);
% 
% scatter(time, angle_of_approach, 'filled');
% xlabel('Time (s)');
% ylabel('Angle of Approach (degrees)');
% title('Angle of Approach vs Time');
% grid on;
% 
% %% Second Plot: Angle of Approach vs Initial Distance
% robot_pos = filtered_initial_data(:,5:6);
% ball_pos = filtered_initial_data(:,1:2);
% distances = sqrt(sum((robot_pos - ball_pos).^2, 2));
% 
% figure;
% scatter(distances, angle_of_approach, 'filled');
% xlabel('Initial Distance Between Robot and Ball');
% ylabel('Angle of Approach (degrees)');
% title('Angle of Approach vs Initial Distance');
% grid on;
% 
% %% Third Plot: Angle of Approach vs Angle Between Robot-Ball Vector and Velocity Direction
% % Velocity direction vector from angle in col 4 of initial data
% angles_rad = filtered_initial_data(:,4) * pi;
% velocity_dirs = [cos(angles_rad), sin(angles_rad)];
% 
% % Vector from ball to robot
% vec_robot_to_ball = robot_pos - ball_pos;
% 
% % Normalize both vectors
% norm_vec = sqrt(sum(vec_robot_to_ball.^2, 2));
% norm_vel = sqrt(sum(velocity_dirs.^2, 2));
% 
% dot_products = sum(vec_robot_to_ball .* velocity_dirs, 2);
% cos_theta = dot_products ./ (norm_vec .* norm_vel);
% angle_between = acosd(max(min(cos_theta,1),-1));  % Clamp to avoid NaNs due to numerical error
% 
% figure;
% scatter(angle_between, angle_of_approach, 'filled');
% xlabel('Angle Between Robot-Ball Vector and Velocity Vector (degrees)');
% ylabel('Angle of Approach (degrees)');
% title('Angle of Approach vs Vector Alignment');
% grid on;




