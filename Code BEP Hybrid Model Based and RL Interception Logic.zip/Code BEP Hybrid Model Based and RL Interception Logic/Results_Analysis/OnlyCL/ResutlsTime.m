close all; clear all; clc

%All data from ball pos [0,0], [1,0], [0,-1], [-2,3], [3,0], [2,-3], [0,-4]
%Use all robot pos [-3,0], [-1.5,0], [0,2]
%All bal velocities {0, 0.5, 1, 1.5}
%% Load Data
data =load('new_data.mat');
data = data.new_data;

initial_data = load('new_initial_data.mat');
initial_data = initial_data.new_initial_data;

successful_mask = data(:,1) >= -4 & data(:,1) <= 4 & data(:,2) >= -6 & data(:,2) <= 6 & data(:,167) < 3000;
% mask_robot_pos_cl = initial_data(:,5) == -3 & initial_data(:,6) == 0 | initial_data(:,5) == -1.5 & initial_data(:,6) == 0 | initial_data(:,5) == 0 & initial_data(:,6) == 2;
% mask_ball_pos_cl = initial_data(:,1) == -3 & initial_data(:,2) == 0 | initial_data(:,1) == -1.5 & initial_data(:,6) == 0 | initial_data(:,5) == 0 & initial_data(:,6) == 2;

mask_velocity_cl = initial_data(:, 3) == 0 | ...
                   initial_data(:, 3) == 0.5 | ...
                   initial_data(:, 3) == 1 | ...
                   initial_data(:, 3) == 1.5;
% mask_velocity_not_cl = initial_data(:, 3) == 2.5;

distances = sqrt((initial_data(:,1) - initial_data(:,5)).^2 + ...
                 (initial_data(:,2) - initial_data(:,6)).^2);

% Create mask for distance > 3.5
mask_distance = distances < 3.5;

combined_mask_cl = mask_velocity_cl & successful_mask & mask_distance;

filtered_data = data(combined_mask_cl, :);
filtered_initial_data = initial_data(combined_mask_cl, :);





%% 3D plot

%% Extract Data
time = filtered_data(:,167)*0.02;
robot_pos = filtered_initial_data(:,5:6);
ball_pos = filtered_initial_data(:,1:2);
angles_rad = filtered_initial_data(:,4) * pi;

%% 1. Bar Plot: Angle of Approach vs Time (binned)
velocity = filtered_initial_data(:,3);
initial_velocity_bins = -0.25:0.5:1.75;  % Define time bin edges
%[~, ~, bin_velocity] = histcounts(velocity, initial_velocity_bins);

% Bin centers
centers_velocity = initial_velocity_bins(1:end-1) + diff(initial_velocity_bins)/2;

% Assign each value to a bin (returns NaN for out-of-range)
bin_velocity = discretize(velocity, initial_velocity_bins);

% Use findgroups & splitapply (ignores NaNs)
[G, valid] = findgroups(bin_velocity(~isnan(bin_velocity)));
mean_time_velocity = splitapply(@mean, time(~isnan(bin_velocity)), G);

% For plotting: initialize with NaNs and insert values into correct positions
mean_aoa_velocity = NaN(size(centers_velocity));
mean_aoa_velocity(unique(bin_velocity(~isnan(bin_velocity)))) = mean_time_velocity;


% Mean AoA per bin
%mean_aoa_velocity = accumarray(bin_velocity, time, [length(centers_velocity), 1], @mean, NaN);

figure;
bar(centers_velocity, mean_aoa_velocity, 'FaceColor', [0.2 0.6 0.8]);
xlabel('Initial Speed [m/s]', 'FontSize', 16);
ylabel('Avg. Time [s]', 'FontSize', 16);
title('Time till Intercept vs Initial Speed (Ball)', 'FontSize', 18);
set(gca, 'FontSize', 14);
grid on;

%% 2. Bar Plot: Angle of Approach vs Initial Distance (binned)
distances = sqrt(sum((robot_pos - ball_pos).^2, 2));
edges_dist = 0.75:0.5:3.25;
[~, ~, bin_dist] = histcounts(distances, edges_dist);
centers_dist = edges_dist(1:end-1) + diff(edges_dist)/2;

mean_aoa_dist = accumarray(bin_dist, time, [length(centers_dist), 1], @mean, NaN);

figure;
bar(centers_dist, mean_aoa_dist, 'FaceColor', [0.3 0.7 0.3]);
xlabel('Initial Distance [m]', 'FontSize', 16);
ylabel('Avg. Time [s]', 'FontSize', 16);
title('Time till Intercept vs Initial Distance', 'FontSize', 18);
set(gca, 'FontSize', 14)
grid on;

%% 3. Bar Plot: Angle of Approach vs Vector Alignment Angle (binned)
velocity_dirs = [cos(angles_rad), sin(angles_rad)];
vec_robot_to_ball = robot_pos - ball_pos;

% Compute angle between vectors
norm_vec = sqrt(sum(vec_robot_to_ball.^2, 2));
norm_vel = sqrt(sum(velocity_dirs.^2, 2));
dot_products = sum(vec_robot_to_ball .* velocity_dirs, 2);
cos_theta = dot_products ./ (norm_vec .* norm_vel);
cos_theta = max(min(cos_theta, 1), -1);  % Clamp for numerical safety
angle_between = acosd(cos_theta);  % in degrees

edges_angle = 0:45:180;
[~, ~, bin_angle] = histcounts(angle_between, edges_angle);
centers_angle = edges_angle(1:end-1) + diff(edges_angle)/2;

mean_aoa_angle = accumarray(bin_angle, time, [length(centers_angle), 1], @mean, NaN);

figure;
bar(centers_angle, mean_aoa_angle, 'FaceColor', [0.8 0.4 0.4]);
xlabel('Angle Between Robot-Ball Vector and Velocity Direction (°)');
ylabel('Avg. Time (s)');
title('Time till intercept vs Vector Alignment Angle (Binned)');
grid on;

% Angle between robot-ball vector and velocity direction (0–180 degrees)
edges_angle = -22.5:45:202.5;
centers_angle = edges_angle(1:end-1) + diff(edges_angle)/2;

% Assign each value to a bin (returns NaN for out-of-range)
bin_angle = discretize(angle_between, edges_angle);

% Use findgroups & splitapply (ignores NaNs)
[G, valid] = findgroups(bin_angle(~isnan(bin_angle)));
mean_time = splitapply(@mean, time(~isnan(bin_angle)), G);

% For plotting: initialize with NaNs and insert values into correct positions
mean_aoa_angle = NaN(size(centers_angle));
mean_aoa_angle(unique(bin_angle(~isnan(bin_angle)))) = mean_time;

% Plot
figure;
bar(centers_angle, mean_aoa_angle, 'FaceColor', [0.8 0.4 0.4]);
xlabel('Initial Angle [degrees]', 'FontSize', 16);
ylabel('Avg. Time [s]', 'FontSize', 16);
title('Time till Intercept vs Initial Angle', 'FontSize', 18);
set(gca, 'FontSize', 14)
grid on;




