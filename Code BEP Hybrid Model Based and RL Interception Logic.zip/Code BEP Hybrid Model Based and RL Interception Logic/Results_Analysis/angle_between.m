function angle = angle_between(v1, v2)
    % Compute dot product
    dot_product = dot(v1, v2);

    % Compute magnitudes
    mag1 = norm(v1);
    mag2 = norm(v2);

    % Prevent division by zero and clamp cosine to [-1, 1]
    if mag1 == 0 || mag2 == 0
        cos_theta = 0;
    else
        cos_theta = dot_product / (mag1 * mag2);
        cos_theta = max(-1, min(1, cos_theta)); % Clamp to avoid domain errors
    end

    % Return angle in radians
    angle = acos(cos_theta);
end