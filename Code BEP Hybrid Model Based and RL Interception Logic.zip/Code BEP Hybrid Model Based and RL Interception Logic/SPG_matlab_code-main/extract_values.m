p_robot = d.setpoint.p;
v_robot = d.setpoint.v;