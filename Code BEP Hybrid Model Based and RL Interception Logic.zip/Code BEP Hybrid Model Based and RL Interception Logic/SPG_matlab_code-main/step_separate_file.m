s.d.target.v = action_target_velocity;

robot_target_vel = s.d.target.v;
s.sim.robot_target_vel = to_vec(s.sim.t, robot_target_vel);

d = getSampleData(s, d, i);

d = spg.next_sample(d);

function vec = to_vec(t,x)
vec.time = t;
vec.signals.values = repmat(x,[1 1 length(t)]);
vec.signals.dimensions = size(x);
end