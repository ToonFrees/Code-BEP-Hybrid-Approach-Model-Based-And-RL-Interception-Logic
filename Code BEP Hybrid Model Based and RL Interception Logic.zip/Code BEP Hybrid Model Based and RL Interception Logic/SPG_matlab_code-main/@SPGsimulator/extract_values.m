

%% Initializing
%Obstacles
p_input_obstacles = d.input.obstacles.p;
v_input_obstacles = d.input.obstacles.v;
%Target
p_input_target = s.d.target.p;
%Robot
p_input_robot = d.input.robot.p;
v_input_robot = d.input.robot.v;

%% Update State
%Obstacles
p_all_obstacles = d.input.obstacles.p;
v_all_obstacles = d.input.obstacles.v;
%Target
p_target = d.target.p;
%Robot
p_robot = d.setpoint.p;
v_robot = d.setpoint.v;
%Ball
p_ball = d.input.robot.target;

traj_robot = d.traj.p;
%ETA
eta = d.target.eta;

%disp("Assigning p_all_obstacles to base workspace")

assignin('base', 'p_all_obstacles', p_all_obstacles);
assignin('base', 'v_all_obstacles', v_all_obstacles);
assignin('base', 'p_target', p_target);
assignin('base', 'v_robot', v_robot);
assignin('base', 'p_robot', p_robot);
assignin('base', 'traj_robot', traj_robot);
assignin('base', 'eta', eta);