function [dpos] = pos_variance(d)
%POS_VARIANCE Summary of this function goes here
%   Detailed explanation goes here
relative_position = d.input.robot.p(1,1:2) - d.input.robot.target(1,1:2);
distance = norm(relative_position);
direction = relative_position/distance;
p_sd_d = [0.0194 9.5742e-4];
p_sd_thd = [0.001 0.0059];
mu = 0;
sigma_d = p_sd_d(1)*distance + p_sd_d(2); % meters
sigma_thd = p_sd_thd(1)*distance + p_sd_thd(2); % meters

dd = normrnd(mu, sigma_d);
dthd = normrnd(mu, sigma_thd);

R90 = [0 -1; 1 0];
tangent = direction*R90;
% assuming the th is small enough to be linear
dpos = [(dd*direction+dthd*tangent) 0];
end

