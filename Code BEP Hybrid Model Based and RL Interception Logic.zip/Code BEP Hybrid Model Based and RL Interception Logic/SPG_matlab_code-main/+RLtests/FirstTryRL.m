%% Define RL Environment
env = SPGsimulator;
obsInfo = getObservationInfo(env);
actInfo = getActionInfo(env);
% obsInfo = rlNumericSpec([8 1], 'LowerLimit', [-4; -6; -4; -6; -10; -10; -10; -10], ...
%                                    'UpperLimit', [4; 6; 4; 6; 10; 10; 10; 10]);
% obsInfo.Name = 'State';
% obsInfo.Description = 'RobotX, RobotY, BallX, BallY, VelocityX, VelocityY, ObstacleX, ObstacleY';
% 
% actionInfo = rlNumericSpec([2 1], 'LowerLimit', [-5; -5], 'UpperLimit', [5; 5]);
% actionInfo.Name = 'TargetVelocity';
% 
% 
% 
% env = rlFunctionEnv(obsInfo, actionInfo, @stepFunction, @resetFunction);



%% Define RL Agent
agentOpts = rlDDPGAgentOptions(...
    'SampleTime', 0.1, ...
    'DiscountFactor', 0.99);

actorNet = [featureInputLayer(8, 'Name', 'state')
            fullyConnectedLayer(32, 'Name', 'fc1')
            reluLayer('Name', 'relu1')
            fullyConnectedLayer(32, 'Name', 'fc2')
            reluLayer('Name', 'relu2')
            fullyConnectedLayer(2, 'Name', 'action')];

actor = rlContinuousDeterministicActor(actorNet, obsInfo, actionInfo);

criticNet = [featureInputLayer(10, 'Name', 'stateAction')
             fullyConnectedLayer(32, 'Name', 'fc1')
             reluLayer('Name', 'relu1')
             fullyConnectedLayer(1, 'Name', 'QValue')];

critic = rlQValueFunction(criticNet, obsInfo, actionInfo);

agent = rlDDPGAgent(actor, critic, agentOpts);

%% Training Parameters
trainOpts = rlTrainingOptions(...
    'MaxEpisodes', 1000, ...
    'MaxStepsPerEpisode', 200, ...
    'StopTrainingCriteria', 'AverageReward', ...
    'StopTrainingValue', 500);

%% Train the Agent
trainingStats = train(agent, env, trainOpts);

%% Step Function (Environment Dynamics and Reward Function)
function [nextObs, reward, isDone, loggedSignals] = stepFunction(loggedSignals, action)
    s.d.target.v = [action(1) action(2) 0];
    robotX = d.setpoint.p(:, 1); robotY = d.setpoint.p(:, 2);
    robotvelocityX = d.setpoint.v(:, 1); robotvelocityY = d.setpoint.v(:, 2);
    ballX = d.target.p(:, 1); ballY = d.target.p(:, 2);
    obstacleX = d.input.obstacles.p(d.input.obstacles.active, 1); % Adding dynamic movement
    obstacleY = d.input.obstacles.p(d.input.obstacles.active, 2);
    
    % Update position
    nextX = robotX + robotvelocityX * 0.02;
    nextY = robotY + robotvelocityY * 0.02;

    % Compute distance to ball
    distance = sqrt((nextX - ballX)^2 + (nextY - ballY)^2);
   
    % Reward function
    reward = -distance;  % Reward for getting closer to the ball
    for i = 1:nobstacles
        collision = sqrt((nextX - obstacleX(i))^2 + (nextY - obstacleY(i))^2) < d.par.robot_radius+d.input.obstacles.r(d.input.obstacles.active);
        if collision
        reward = reward - 50; % Heavy penalty for collision
        end
    end

    if abs(nextX) > 10 || abs(nextY) > 10
        reward = reward - 100; % Heavy penalty for going out of bounds
    end
    if distance < 0.5
        reward = reward + 100; % Large reward for reaching the ball
        isDone = true;
    else
        isDone = false;
    end
    
    nextObs = [nextX; nextY; ballX; ballY; velocityX; velocityY; obstacleX; obstacleY];
    loggedSignals = struct;
end

function[InitialObservation,LoggedSignals] = resetFunction()
    run(s);
    robotX = d.input_robot.p(:, 1); robotY = d.input_robot.p(:, 2);
    robotvelocityX = d.input_robot.v(:, 1); robotvelocityY = d.input_robot.v(:, 2);
    ballX = s.d.target.p(:, 1); ballY = s.d.target.p(:, 2);
    obstacleX = d.input.obstacles.p(:, 1); 
    obstacleY = d.input.obstacles.p(:, 2);
    InitialObservation = [robotX, robotY, ballX, ballY, robotvelocityX, robotvelocityY, obstacleX, obstacleY];
    LoggedSignals = struct;
end


