%compute subtarget trajectory
[subtarget, p_robot, p_obs] = spg.subtarget.check_collisionfree(d, d.subtarget, 0);
% d.aux.segment = spg.setpoint.get_segments(d.aux.segment, d.setpoint.p, d.setpoint.v, d.subtarget.p, [0 0 0], d.subtarget.vmax, d.subtarget.amax, d.par.dmax_move);
% d = spg.setpoint.traj_predict(d, d.aux.segment);
s.h.traj_subtarget.XData = p_robot(:,1);
s.h.traj_subtarget.YData = p_robot(:,2);
p_obs_x = permute(cat(3,p_obs(:,1,:),nan(size(p_obs,1),1)),[3 1 2]);
p_obs_y = permute(cat(3,p_obs(:,2,:),nan(size(p_obs,1),1)),[3 1 2]);
s.h.traj_obs.XData = p_obs_x(:);
s.h.traj_obs.YData = p_obs_y(:);

%compute target trajectory
subtarget_target = spg.subtarget.replan.to_target(d);
d.aux.segment = spg.setpoint.get_segments(d.aux.segment, d.setpoint.p, d.setpoint.v, subtarget_target.p, subtarget_target.v, subtarget_target.vmax, subtarget_target.amax, [d.par.dmax_move, d.par.dmax_move, d.par.dmax_rotate]);
d = spg.setpoint.traj_predict(d, d.aux.segment);
s.h.traj_target.XData = d.traj.p(:,1);
s.h.traj_target.YData = d.traj.p(:,2);
traject_to_subtarget = d.traj.p;

%update graphics
if ~mod(i,s.update_step)
    if s.d0.par.nobstacles < 1
%         s.h.obstacles.XData = 0;
%         s.h.obstacles.YData = ;   
%         s.h.obstacles.ZData(:,d.input.obstacles.active) = 0;
%         s.h.obstacles.ZData(:,~d.input.obstacles.active) = nan;
    else
        s.h.obstacles.XData = bsxfun(@plus,d.input.obstacles.p(:,1)',s.h.shape_obstacle(:,1));
        s.h.obstacles.YData = bsxfun(@plus,d.input.obstacles.p(:,2)',s.h.shape_obstacle(:,2));
        s.h.obstacles.ZData(:,d.input.obstacles.active) = 0;
        s.h.obstacles.ZData(:,~d.input.obstacles.active) = nan;
    end

    set_shape(s.h.setpoint, d.setpoint.p, s.h.shape_robot);
    set_shape(s.h.collision, d.setpoint.p, s.h.shape_collision);
    set_shape(s.h.subtarget, d.subtarget.p, s.h.shape_robot);
    set_shape(s.h.target_shifted, d.target.p, s.h.shape_robot);
    set_shape(s.h.target, d.input.robot.target, s.h.shape_robot);

    % Added by Geert to visualize the target velocity and ball actual ball
    % location
    %temp_angle = acos(dot([1 0], d.input.robot.target_vel(1:2)) / (norm([1 0]) * norm(d.input.robot.target_vel(1:2))));
    temp_angle = atan2(d.input.robot.target_vel(1), d.input.robot.target_vel(2));
    set_shape(s.h.target_v, [d.input.robot.target(1:2) temp_angle], s.h.shape_arrow*(norm(d.input.robot.target_vel(1:2))/3))
    set_shape(s.h.ball, [d.ball.p 0], s.h.shape_ball)
    %temp_angle2 = acos(dot([1 0], d.input.ball.v) / (norm([1 0]) * norm(d.input.ball.v)));
    temp_angle2 = atan2(d.input.ball.v(1), d.input.ball.v(2));
    set_shape(s.h.ball_v, [d.ball.p(1:2) temp_angle2], s.h.shape_arrow*(norm(d.input.ball.v(1:2))/3))

    if(d.input.SubtargetAvoidPolygon.valid)
        s.h.SubtargetAvoidPolygon.XData = d.input.SubtargetAvoidPolygon.polygon(1,:);
        s.h.SubtargetAvoidPolygon.YData = d.input.SubtargetAvoidPolygon.polygon(2,:);
        s.h.SubtargetAvoidPolygon.ZData = zeros(1, size(d.input.SubtargetAvoidPolygon.polygon,2));
    else
        s.h.SubtargetAvoidPolygon.XData = NaN;
        s.h.SubtargetAvoidPolygon.YData = NaN;
        s.h.SubtargetAvoidPolygon.ZData = NaN;
    end

    s.h.info.String = sprintf('time: %1.2f s\nsample: %d\n\nsubtarget:\n - p = [%s]\n - v = [%s]\n - vmax = [%s]\n - amax = [%s]\n - action = %1.0f\n - eta = [%s] s\n - segment id = [%s]\n\nsetpoint:\n - p = [%s]\n - v = [%s]\n - speed = %1.2f m/s',...
        i*d.par.Ts, i, num2str(d.subtarget.p,'%1.2f '), num2str(d.subtarget.v,'%1.2f '),num2str(d.subtarget.vmax,'%1.2f '),num2str(d.subtarget.amax,'%1.2f '),d.subtarget.action,num2str(d.subtarget.segment(3).t,'%1.2f '),num2str(d.subtarget.segment_id,'%1.0f '),...
        num2str(d.setpoint.p,'%1.2f '),num2str(d.setpoint.v,'%1.2f '), norm(d.setpoint.v(1:2)));

    drawnow
end

%use breakpoint here to stop at newly planned subtargets
if d.subtarget.action==2
end

%save position data
log(i,:) = d.setpoint.p;

if i==1
    % save collision scenario for debugging SPG code
    s.sim.error.obstP = d.input.obstacles.p;
    s.sim.error.obstV = d.input.obstacles.v;
end

%if collision, fail the test
p_obstacles = d.input.obstacles.p(d.input.obstacles.active,:);
r_obstacles = d.input.obstacles.r(d.input.obstacles.active);
collision_distance = d.par.robot_radius+r_obstacles;
if ~isempty(p_obstacles)
    smallest_robot2obstacle_dist = min(abs( vecnorm(d.input.robot.p(1:2) - p_obstacles(:,1:2),2,2) ) - collision_distance);
    s.sim.error.smallest_robot2obstacle_dist(i) = smallest_robot2obstacle_dist;
%     if smallest_robot2obstacle_dist < 0
%         error('collision occured');
%     end
end

i = mod(i,nsim)+1;

%% Initializing
% Obstacles
p_input_obstacles = d.input.obstacles.p;
v_input_obstacles = d.input.obstacles.v;

% Target
p_input_ball = d.input.ball.p;
v_input_ball = d.input.ball.v;

% Robot
p_input_robot = d.input.robot.p;
v_input_robot = d.input.robot.v(1:2);
skillID_robot = d.input.robot.skillID;
CPPA_robot = d.input.robot.CPPA;
CPBteam_robot = d.input.robot.CPBteam;
reset_trigger_robot = d.input.robot.reset_trigger;
quickstop_trigger_robot = d.input.robot.quickstop_trigger;
cpb_poi_xy_robot = d.input.robot.cpb_poi_xy;
IMU_orientation = d.input.robot.IMU_orientation;
human_dribble_flag = d.input.robot.human_dribble_flag;
dist2ball_vs_opp = d.input.robot.dist2ball_vs_opp;

% SubtargetAvoidPolygon
polygon = d.input.SubtargetAvoidPolygon.polygon;
valid = d.input.SubtargetAvoidPolygon.valid;

%% Update State
% Obstacles
p_all_obstacles = d.input.obstacles.p;
v_all_obstacles = d.input.obstacles.v;
obstacles_active = d.input.obstacles.active;

% Target
p_target = d.target.p(1:2);
v_target = d.target.v_variance;
target_velocity = d.target.v(1:2);

% Ball
p_ball = d.ball.p;
v_ball = d.input.ball.v;

% Robot
p_robot = d.setpoint.p;
v_robot = d.setpoint.v(1:2);
a_robot = d.setpoint.a;

traj_robot_p = d.traj.p(:, 1:2);
traj_robot_v = d.traj.v(:, 1:2);
traj_robot_a = d.traj.a(:, 1:2);

% Subtarget
subtarget_p = d.subtarget.p;
subtarget_v = d.subtarget.v(1:2);
subtarget_vmax = d.subtarget.vmax;
subtarget_amax = d.subtarget.amax;
subtarget_dmax = d.subtarget.dmax;
subtarget_action = d.subtarget.action;
subtarget_collisionfree = d.subtarget.collisionfree;
subtarget_target = d.subtarget.target(1:2);
subtarget_eta = d.subtarget.eta;
subtarget_age = d.subtarget.age;
subtarget_violation_count = d.subtarget.violation_count;
subtarget_automatic_substitution_flag = d.subtarget.automatic_substitution_flag;

% ETA
eta = d.target.eta;

%Angles
%Trajectory velocity is opposite to the velocity of the ball(with variance)
for i= 1:20
    traj_vel = traj_robot_v(i, 1:2);
    angle_traj_vel_ball_vel(i) = angle_between(-traj_vel, v_target);
end
%Angle right at the end
angle_robot_ball_end = angle_between(-v_robot, v_target);
%Angle robot vel away from going straight to the target
angle_robotball_vel = angle_between(v_target, p_robot(1:2)-p_target);

%Distance_robot_to_ball
distance = norm(p_ball - p_robot(1:2));

% Compute distances
distance_traj_vel = zeros(20, 1);

for i = 1:20
    p = traj_robot_p(i, :);                 % [x, y] of trajectory point

    if all(p == 0) && all(p_target == 0)
        distance_traj_vel(i) = 0;
    else
        delta = p - p_target;                    % vector from p_target to p
        numerator = abs(v_target(1) * delta(2) - v_target(2) * delta(1));  % |vx*dy - vy*dx|
        denominator = norm(v_target);            % ||v_target||

        if denominator == 0
            distance_traj_vel(i) = 0;  % or some fallback value if v_target is zero
        else
            distance_traj_vel(i) = numerator / denominator;
        end
    end
end

%% Assign all variables to base workspace
vars = {
    'p_input_obstacles', 'v_input_obstacles', ...
    'p_input_ball', 'v_input_ball', ...
    'p_input_robot', 'v_input_robot', 'skillID_robot', ...
    'CPPA_robot', 'CPBteam_robot', 'reset_trigger_robot', ...
    'quickstop_trigger_robot', 'cpb_poi_xy_robot', ...
    'IMU_orientation', 'human_dribble_flag', ...
    'dist2ball_vs_opp', ...
    'polygon', 'valid', ...
    'p_all_obstacles', 'v_all_obstacles', 'obstacles_active', ...
    'p_target', 'v_target', 'target_velocity', ...
    'p_ball', 'v_ball', ...
    'p_robot', 'v_robot', 'a_robot', ...
    'traj_robot_p', 'traj_robot_v', 'traj_robot_a', ...
    'subtarget_p', 'subtarget_v', 'subtarget_vmax', ...
    'subtarget_amax', 'subtarget_dmax', 'subtarget_action', ...
    'subtarget_collisionfree', 'subtarget_target', ...
    'subtarget_eta', 'subtarget_age', ...
    'subtarget_violation_count', ...
    'subtarget_automatic_substitution_flag', ...
    'eta', 'distance', 'angle_robotball_vel', ...
    'angle_robot_ball_end', 'angle_traj_vel_ball_vel',...
    'distance_traj_vel'
};

for i = 1:numel(vars)
    assignin('base', vars{i}, eval(vars{i}));
end

% for i = 1:numel(vars)
%     var_value = eval(vars{i});
%     if isa(var_value, 'gpuArray')
%         var_value = gather(var_value);  % Move to CPU
%     end
%     assignin('base', vars{i}, var_value);
% end

function set_shape(h, p, shape)

R = functions.rot(p(3));
xy = bsxfun(@plus,p(1:2)',R*shape');
h.XData = xy(1,:);
h.YData = xy(2,:);
h.ZData = zeros(1,size(xy,2));

end