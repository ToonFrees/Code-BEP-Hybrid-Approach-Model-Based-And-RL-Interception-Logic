function [planning] = planning_test(d)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
distance = norm(d.input.robot.target(1:2) - d.setpoint.p(1:2));
distance_cutoff = 0.5;
if distance > distance_cutoff
    planning = 20*(distance-distance_cutoff);
else
    planning = 0;
end