% close all
% clear classes
% clc
global s d i;
% %setpoint generator
%p_initial = [-1 0 0];
%v_initial = [0 3 0];
%npredict    = 20;
%nobstacles  = min(9, 78);
%nintercept_positions = 15;
%p_initial_ball = [0 0];
%v_initial_ball = [0 0];
% p_initial = gpuArray(p_initial);
% v_initial = gpuArray(v_initial);
% nobstacles = gpuArray(nobstacles);
% p_initial_ball = gpuArray(p_initial_ball);
% v_initial_ball = gpuArray(v_initial_ball);
% nintercept_positions = gpuArray(nintercept_positions);
d = spg.init(p_initial, v_initial, nobstacles, npredict, p_initial_ball, v_initial_ball, nintercept_positions);

%run('testRL.m')

%simulation
s = SPGsimulator(d);
s.d.target.p = [d.input.ball.p, 0];%p_input_target;
%run('+RLtests\FirstTryRL.m')
%s.d.target.v = [1 0 0];



setData(s);
% run(s);
%run_1_step(s)
% rng(0)
% p_robot = d.input.robot.p;

%preparations
d = s.d;
i = s.sim.i;
nsim = length(s.sim.t);
log = s.log;
s.h.run_stop.BackgroundColor = [0 1 0];
d.setpoint.v = d.input.robot.v;



%% Initializing
% Obstacles
p_input_obstacles = d.input.obstacles.p;
v_input_obstacles = d.input.obstacles.v;

% Target
p_input_ball = d.input.ball.p;
v_input_ball = d.input.ball.v;

% Robot
p_input_robot = d.input.robot.p;
v_input_robot = d.input.robot.v(1:2);
skillID_robot = d.input.robot.skillID;
CPPA_robot = d.input.robot.CPPA;
CPBteam_robot = d.input.robot.CPBteam;
reset_trigger_robot = d.input.robot.reset_trigger;
quickstop_trigger_robot = d.input.robot.quickstop_trigger;
cpb_poi_xy_robot = d.input.robot.cpb_poi_xy;
IMU_orientation = d.input.robot.IMU_orientation;
human_dribble_flag = d.input.robot.human_dribble_flag;
dist2ball_vs_opp = d.input.robot.dist2ball_vs_opp;

% SubtargetAvoidPolygon
polygon = d.input.SubtargetAvoidPolygon.polygon;
valid = d.input.SubtargetAvoidPolygon.valid;

%% Update State
% Obstacles
p_all_obstacles = d.input.obstacles.p;
v_all_obstacles = d.input.obstacles.v;
obstacles_active = d.input.obstacles.active;

% Target
p_target = d.target.p(1:2);
v_target = d.target.v_variance;
target_velocity = d.target.v(1:2);

% Ball
p_ball = d.ball.p;
v_ball = d.input.ball.v;

% Robot
p_robot = d.setpoint.p;
v_robot = d.setpoint.v(1:2);
a_robot = d.setpoint.a;

traj_robot_p = d.traj.p(:, 1:2);
traj_robot_v = d.traj.v(:, 1:2);
traj_robot_a = d.traj.a(:, 1:2);

% Subtarget
subtarget_p = d.subtarget.p;
subtarget_v = d.subtarget.v(1:2);
subtarget_vmax = d.subtarget.vmax;
subtarget_amax = d.subtarget.amax;
subtarget_dmax = d.subtarget.dmax;
subtarget_action = d.subtarget.action;
subtarget_collisionfree = d.subtarget.collisionfree;
subtarget_target = d.subtarget.target(1:2);
subtarget_eta = d.subtarget.eta;
subtarget_age = d.subtarget.age;
subtarget_violation_count = d.subtarget.violation_count;
subtarget_automatic_substitution_flag = d.subtarget.automatic_substitution_flag;

% ETA
eta = d.target.eta;

%Angles
%Trajectory velocity is opposite to the velocity of the ball(with variance)
for i= 1:20
    traj_vel = traj_robot_v(i, 1:2);
    angle_traj_vel_ball_vel(i) = angle_between(-traj_vel, v_target);
end
%Angle right at the end
angle_robot_ball_end = angle_between(-v_robot, v_target);
%Angle robot vel away from going straight to the target
angle_robotball_vel = angle_between(v_robot, p_robot(1:2)-p_target);

%Distance_robot_to_ball
distance = norm(p_ball - p_robot(1:2));



% Compute distances
distance_traj_vel = zeros(20, 1);

for i = 1:20
    p = traj_robot_p(i, :);                 % [x, y] of trajectory point

    if all(p == 0) && all(p_target == 0)
        distance_traj_vel(i) = 0;
    else
        delta = p - p_target;                    % vector from p_target to p
        numerator = abs(v_target(1) * delta(2) - v_target(2) * delta(1));  % |vx*dy - vy*dx|
        denominator = norm(v_target);            % ||v_target||

        if denominator == 0
            distance_traj_vel(i) = 0;  % or some fallback value if v_target is zero
        else
            distance_traj_vel(i) = numerator / denominator;
        end
    end
end


%% Assign all variables to base workspace
vars = {
    'p_input_obstacles', 'v_input_obstacles', ...
    'p_input_ball', 'v_input_ball', ...
    'p_input_robot', 'v_input_robot', 'skillID_robot', ...
    'CPPA_robot', 'CPBteam_robot', 'reset_trigger_robot', ...
    'quickstop_trigger_robot', 'cpb_poi_xy_robot', ...
    'IMU_orientation', 'human_dribble_flag', ...
    'dist2ball_vs_opp', ...
    'polygon', 'valid', ...
    'p_all_obstacles', 'v_all_obstacles', 'obstacles_active', ...
    'p_target', 'v_target', 'target_velocity', ...
    'p_ball', 'v_ball', ...
    'p_robot', 'v_robot', 'a_robot', ...
    'traj_robot_p', 'traj_robot_v', 'traj_robot_a', ...
    'subtarget_p', 'subtarget_v', 'subtarget_vmax', ...
    'subtarget_amax', 'subtarget_dmax', 'subtarget_action', ...
    'subtarget_collisionfree', 'subtarget_target', ...
    'subtarget_eta', 'subtarget_age', ...
    'subtarget_violation_count', ...
    'subtarget_automatic_substitution_flag', ...
    'eta', 'distance', 'angle_robotball_vel', ...
    'angle_robot_ball_end', 'angle_traj_vel_ball_vel',...
    'distance_traj_vel'
};

for i = 1:numel(vars)
    assignin('base', vars{i}, eval(vars{i}));
end

% for i = 1:numel(vars)
%     var_value = eval(vars{i});
%     if isa(var_value, 'gpuArray')
%         var_value = gather(var_value);  % Move to CPU
%     end
%     assignin('base', vars{i}, var_value);
% end

% %simulation data
% d = getSampleData(s, d, i); %set d.input.robot, d.input.obstacles, d.par.*
% 
% %perfect robot tracking
% d.input.robot.p = d.setpoint.p;
% d.input.robot.v = d.setpoint.v;
% 
% %save robot path and velocity
% s.sim.error.path(i,:) = d.input.robot.p(1:2);
% s.sim.error.vel(i,:) = d.input.robot.v(1:2);

% for j = 1:100
%     %step 1 sample
%     d = step(s, d);
% 
%     %update visualisation
%     update(s, d, i);
% end
% 
% p_robot = d.input.robot.p;