function [v_with_variance] = getVarianceVelocity(d)

data = load('polyfit_coeffs.mat');
p = data.p;
distance = norm(d.ball.p(1:2)-d.setpoint.p(1:2));
std = polyval(p, distance);

% Sample one angle error from the normal distribution
angle_error = normrnd(0, std);  % angle_error is now a random error


R = [cos(angle_error), -sin(angle_error);
     sin(angle_error),  cos(angle_error)];

% Rotate vector
v_with_variance = (R * d.input.ball.v(:))';

